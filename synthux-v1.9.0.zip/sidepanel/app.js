import"./chunks/chunk-Y6SLVHK3.js";var H=globalThis,L=H.ShadowRoot&&(H.ShadyCSS===void 0||H.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,N=Symbol(),ne=new WeakMap,C=class{constructor(e,t,s){if(this._$cssResult$=!0,s!==N)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(L&&e===void 0){let s=t!==void 0&&t.length===1;s&&(e=ne.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),s&&ne.set(t,e))}return e}toString(){return this.cssText}},le=r=>new C(typeof r=="string"?r:r+"",void 0,N),g=(r,...e)=>{let t=r.length===1?r[0]:e.reduce((s,i,a)=>s+(o=>{if(o._$cssResult$===!0)return o.cssText;if(typeof o=="number")return o;throw Error("Value passed to 'css' function must be a 'css' function result: "+o+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+r[a+1],r[0]);return new C(t,r,N)},ce=(r,e)=>{if(L)r.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(let t of e){let s=document.createElement("style"),i=H.litNonce;i!==void 0&&s.setAttribute("nonce",i),s.textContent=t.cssText,r.appendChild(s)}},B=L?r=>r:r=>r instanceof CSSStyleSheet?(e=>{let t="";for(let s of e.cssRules)t+=s.cssText;return le(t)})(r):r;var{is:Ce,defineProperty:Ee,getOwnPropertyDescriptor:Pe,getOwnPropertyNames:ze,getOwnPropertySymbols:Te,getPrototypeOf:Oe}=Object,F=globalThis,de=F.trustedTypes,Re=de?de.emptyScript:"",Ie=F.reactiveElementPolyfillSupport,E=(r,e)=>r,D={toAttribute(r,e){switch(e){case Boolean:r=r?Re:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,e){let t=r;switch(e){case Boolean:t=r!==null;break;case Number:t=r===null?null:Number(r);break;case Object:case Array:try{t=JSON.parse(r)}catch{t=null}}return t}},he=(r,e)=>!Ce(r,e),pe={attribute:!0,type:String,converter:D,reflect:!1,useDefault:!1,hasChanged:he};Symbol.metadata??=Symbol("metadata"),F.litPropertyMetadata??=new WeakMap;var b=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=pe){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let s=Symbol(),i=this.getPropertyDescriptor(e,s,t);i!==void 0&&Ee(this.prototype,e,i)}}static getPropertyDescriptor(e,t,s){let{get:i,set:a}=Pe(this.prototype,e)??{get(){return this[t]},set(o){this[t]=o}};return{get:i,set(o){let c=i?.call(this);a?.call(this,o),this.requestUpdate(e,c,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??pe}static _$Ei(){if(this.hasOwnProperty(E("elementProperties")))return;let e=Oe(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(E("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(E("properties"))){let t=this.properties,s=[...ze(t),...Te(t)];for(let i of s)this.createProperty(i,t[i])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[s,i]of t)this.elementProperties.set(s,i)}this._$Eh=new Map;for(let[t,s]of this.elementProperties){let i=this._$Eu(t,s);i!==void 0&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let s=new Set(e.flat(1/0).reverse());for(let i of s)t.unshift(B(i))}else e!==void 0&&t.push(B(e));return t}static _$Eu(e,t){let s=t.attribute;return s===!1?void 0:typeof s=="string"?s:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let s of t.keys())this.hasOwnProperty(s)&&(e.set(s,this[s]),delete this[s]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return ce(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,s){this._$AK(e,s)}_$ET(e,t){let s=this.constructor.elementProperties.get(e),i=this.constructor._$Eu(e,s);if(i!==void 0&&s.reflect===!0){let a=(s.converter?.toAttribute!==void 0?s.converter:D).toAttribute(t,s.type);this._$Em=e,a==null?this.removeAttribute(i):this.setAttribute(i,a),this._$Em=null}}_$AK(e,t){let s=this.constructor,i=s._$Eh.get(e);if(i!==void 0&&this._$Em!==i){let a=s.getPropertyOptions(i),o=typeof a.converter=="function"?{fromAttribute:a.converter}:a.converter?.fromAttribute!==void 0?a.converter:D;this._$Em=i;let c=o.fromAttribute(t,a.type);this[i]=c??this._$Ej?.get(i)??c,this._$Em=null}}requestUpdate(e,t,s,i=!1,a){if(e!==void 0){let o=this.constructor;if(i===!1&&(a=this[e]),s??=o.getPropertyOptions(e),!((s.hasChanged??he)(a,t)||s.useDefault&&s.reflect&&a===this._$Ej?.get(e)&&!this.hasAttribute(o._$Eu(e,s))))return;this.C(e,t,s)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(e,t,{useDefault:s,reflect:i,wrapped:a},o){s&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,o??t??this[e]),a!==!0||o!==void 0)||(this._$AL.has(e)||(this.hasUpdated||s||(t=void 0),this._$AL.set(e,t)),i===!0&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[i,a]of this._$Ep)this[i]=a;this._$Ep=void 0}let s=this.constructor.elementProperties;if(s.size>0)for(let[i,a]of s){let{wrapped:o}=a,c=this[i];o!==!0||this._$AL.has(i)||c===void 0||this.C(i,void 0,a,c)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(s=>s.hostUpdate?.()),this.update(t)):this._$EM()}catch(s){throw e=!1,this._$EM(),s}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(e){}firstUpdated(e){}};b.elementStyles=[],b.shadowRootOptions={mode:"open"},b[E("elementProperties")]=new Map,b[E("finalized")]=new Map,Ie?.({ReactiveElement:b}),(F.reactiveElementVersions??=[]).push("2.1.2");var J=globalThis,ue=r=>r,U=J.trustedTypes,me=U?U.createPolicy("lit-html",{createHTML:r=>r}):void 0,ye="$lit$",v=`lit$${Math.random().toFixed(9).slice(2)}$`,_e="?"+v,Me=`<${_e}>`,w=document,z=()=>w.createComment(""),T=r=>r===null||typeof r!="object"&&typeof r!="function",Q=Array.isArray,He=r=>Q(r)||typeof r?.[Symbol.iterator]=="function",V=`[ 	
\f\r]`,P=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,ge=/-->/g,fe=/>/g,y=RegExp(`>|${V}(?:([^\\s"'>=/]+)(${V}*=${V}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),be=/'/g,xe=/"/g,we=/^(?:script|style|textarea|title)$/i,X=r=>(e,...t)=>({_$litType$:r,strings:e,values:t}),n=X(1),Ge=X(2),We=X(3),$=Symbol.for("lit-noChange"),h=Symbol.for("lit-nothing"),ve=new WeakMap,_=w.createTreeWalker(w,129);function $e(r,e){if(!Q(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return me!==void 0?me.createHTML(e):e}var Le=(r,e)=>{let t=r.length-1,s=[],i,a=e===2?"<svg>":e===3?"<math>":"",o=P;for(let c=0;c<t;c++){let l=r[c],p,u,d=-1,f=0;for(;f<l.length&&(o.lastIndex=f,u=o.exec(l),u!==null);)f=o.lastIndex,o===P?u[1]==="!--"?o=ge:u[1]!==void 0?o=fe:u[2]!==void 0?(we.test(u[2])&&(i=RegExp("</"+u[2],"g")),o=y):u[3]!==void 0&&(o=y):o===y?u[0]===">"?(o=i??P,d=-1):u[1]===void 0?d=-2:(d=o.lastIndex-u[2].length,p=u[1],o=u[3]===void 0?y:u[3]==='"'?xe:be):o===xe||o===be?o=y:o===ge||o===fe?o=P:(o=y,i=void 0);let x=o===y&&r[c+1].startsWith("/>")?" ":"";a+=o===P?l+Me:d>=0?(s.push(p),l.slice(0,d)+ye+l.slice(d)+v+x):l+v+(d===-2?c:x)}return[$e(r,a+(r[t]||"<?>")+(e===2?"</svg>":e===3?"</math>":"")),s]},O=class r{constructor({strings:e,_$litType$:t},s){let i;this.parts=[];let a=0,o=0,c=e.length-1,l=this.parts,[p,u]=Le(e,t);if(this.el=r.createElement(p,s),_.currentNode=this.el.content,t===2||t===3){let d=this.el.content.firstChild;d.replaceWith(...d.childNodes)}for(;(i=_.nextNode())!==null&&l.length<c;){if(i.nodeType===1){if(i.hasAttributes())for(let d of i.getAttributeNames())if(d.endsWith(ye)){let f=u[o++],x=i.getAttribute(d).split(v),M=/([.?@])?(.*)/.exec(f);l.push({type:1,index:a,name:M[2],strings:x,ctor:M[1]==="."?W:M[1]==="?"?K:M[1]==="@"?q:S}),i.removeAttribute(d)}else d.startsWith(v)&&(l.push({type:6,index:a}),i.removeAttribute(d));if(we.test(i.tagName)){let d=i.textContent.split(v),f=d.length-1;if(f>0){i.textContent=U?U.emptyScript:"";for(let x=0;x<f;x++)i.append(d[x],z()),_.nextNode(),l.push({type:2,index:++a});i.append(d[f],z())}}}else if(i.nodeType===8)if(i.data===_e)l.push({type:2,index:a});else{let d=-1;for(;(d=i.data.indexOf(v,d+1))!==-1;)l.push({type:7,index:a}),d+=v.length-1}a++}}static createElement(e,t){let s=w.createElement("template");return s.innerHTML=e,s}};function k(r,e,t=r,s){if(e===$)return e;let i=s!==void 0?t._$Co?.[s]:t._$Cl,a=T(e)?void 0:e._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(r),i._$AT(r,t,s)),s!==void 0?(t._$Co??=[])[s]=i:t._$Cl=i),i!==void 0&&(e=k(r,i._$AS(r,e.values),i,s)),e}var G=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:s}=this._$AD,i=(e?.creationScope??w).importNode(t,!0);_.currentNode=i;let a=_.nextNode(),o=0,c=0,l=s[0];for(;l!==void 0;){if(o===l.index){let p;l.type===2?p=new R(a,a.nextSibling,this,e):l.type===1?p=new l.ctor(a,l.name,l.strings,this,e):l.type===6&&(p=new Y(a,this,e)),this._$AV.push(p),l=s[++c]}o!==l?.index&&(a=_.nextNode(),o++)}return _.currentNode=w,i}p(e){let t=0;for(let s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(e,s,t),t+=s.strings.length-2):s._$AI(e[t])),t++}},R=class r{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,s,i){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=s,this.options=i,this._$Cv=i?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=k(this,e,t),T(e)?e===h||e==null||e===""?(this._$AH!==h&&this._$AR(),this._$AH=h):e!==this._$AH&&e!==$&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):He(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==h&&T(this._$AH)?this._$AA.nextSibling.data=e:this.T(w.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:s}=e,i=typeof s=="number"?this._$AC(e):(s.el===void 0&&(s.el=O.createElement($e(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===i)this._$AH.p(t);else{let a=new G(i,this),o=a.u(this.options);a.p(t),this.T(o),this._$AH=a}}_$AC(e){let t=ve.get(e.strings);return t===void 0&&ve.set(e.strings,t=new O(e)),t}k(e){Q(this._$AH)||(this._$AH=[],this._$AR());let t=this._$AH,s,i=0;for(let a of e)i===t.length?t.push(s=new r(this.O(z()),this.O(z()),this,this.options)):s=t[i],s._$AI(a),i++;i<t.length&&(this._$AR(s&&s._$AB.nextSibling,i),t.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let s=ue(e).nextSibling;ue(e).remove(),e=s}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},S=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,s,i,a){this.type=1,this._$AH=h,this._$AN=void 0,this.element=e,this.name=t,this._$AM=i,this.options=a,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=h}_$AI(e,t=this,s,i){let a=this.strings,o=!1;if(a===void 0)e=k(this,e,t,0),o=!T(e)||e!==this._$AH&&e!==$,o&&(this._$AH=e);else{let c=e,l,p;for(e=a[0],l=0;l<a.length-1;l++)p=k(this,c[s+l],t,l),p===$&&(p=this._$AH[l]),o||=!T(p)||p!==this._$AH[l],p===h?e=h:e!==h&&(e+=(p??"")+a[l+1]),this._$AH[l]=p}o&&!i&&this.j(e)}j(e){e===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}},W=class extends S{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===h?void 0:e}},K=class extends S{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==h)}},q=class extends S{constructor(e,t,s,i,a){super(e,t,s,i,a),this.type=5}_$AI(e,t=this){if((e=k(this,e,t,0)??h)===$)return;let s=this._$AH,i=e===h&&s!==h||e.capture!==s.capture||e.once!==s.once||e.passive!==s.passive,a=e!==h&&(s===h||i);i&&this.element.removeEventListener(this.name,this,s),a&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Y=class{constructor(e,t,s){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(e){k(this,e)}};var Fe=J.litHtmlPolyfillSupport;Fe?.(O,R),(J.litHtmlVersions??=[]).push("3.3.2");var ke=(r,e,t)=>{let s=t?.renderBefore??e,i=s._$litPart$;if(i===void 0){let a=t?.renderBefore??null;s._$litPart$=i=new R(e.insertBefore(z(),a),a,void 0,t??{})}return i._$AI(r),i};var Z=globalThis,m=class extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=ke(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return $}};m._$litElement$=!0,m.finalized=!0,Z.litElementHydrateSupport?.({LitElement:m});var Ue=Z.litElementPolyfillSupport;Ue?.({LitElement:m});(Z.litElementVersions??=[]).push("4.2.2");var Se=5;async function A(){try{return(await chrome.storage.local.get({customProfiles:[]})).customProfiles||[]}catch{return[]}}async function j(r){let e=await A();if(e.length>=Se)throw new Error(`Maximum ${Se} custom profiles allowed`);let t={id:`custom-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,icon:"\u{1F464}",custom:!0,name:{en:r.name,tr:r.name},description:{en:r.description||"",tr:r.description||""},ageRange:r.ageRange||"25-35",techLevel:r.techLevel||"medium",disabilities:r.disabilities||[],goal:r.goal||"",priorityHeuristics:r.priorityHeuristics||[],weight:1,systemPrompt:je(r)};return e.push(t),await chrome.storage.local.set({customProfiles:e}),t}async function I(r){let t=(await A()).filter(s=>s.id!==r);return await chrome.storage.local.set({customProfiles:t}),t}function je(r){let e={low:"not very comfortable with technology, prefers simple interfaces",medium:"moderately comfortable with technology, uses common apps regularly",high:"very tech-savvy, comfortable with complex interfaces and shortcuts"},t={"18-25":"a young adult (18-25) who is digitally native","25-35":"an adult (25-35) with regular internet experience","35-50":"a middle-aged adult (35-50) with moderate tech familiarity","50-65":"an older adult (50-65) who may prefer larger text and simpler layouts","65+":"a senior user (65+) who needs high contrast, large click targets, and simple navigation"},s={vision:"low vision \u2014 needs high contrast, large text, and screen reader support",hearing:"hearing impairment \u2014 relies on captions and visual cues instead of audio",motor:"motor disability \u2014 uses keyboard or switch device, needs large click targets",cognitive:"cognitive disability \u2014 needs simple language, clear structure, and minimal distractions",none:"no disabilities"},i=t[r.ageRange]||t["25-35"],a=e[r.techLevel]||e.medium,o=(r.disabilities||[]).length>0?r.disabilities.map(l=>s[l]||l).join("; "):s.none,c=r.goal||"browsing the page to accomplish a task";return`You are ${i}. You are ${a}.
Your accessibility needs: ${o}.
Your goal on this page: ${c}.

When evaluating this web page, adopt this persona fully. Consider:
- How would someone with your age, tech level, and abilities experience this page?
- Are there barriers that would prevent you from accomplishing your goal?
- Is the language, layout, and interaction design appropriate for your profile?
- Would you feel confident, confused, or frustrated using this page?

Evaluate from YOUR perspective \u2014 not as a generic user.`}var ee=class extends m{static properties={value:{type:Number},label:{type:String},size:{type:String},animated:{type:Boolean},_displayValue:{type:Number,state:!0}};static styles=g`
    :host {
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
    }

    .score-ring {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    svg { transform: rotate(-90deg); }

    .ring-bg {
      fill: none;
      stroke: var(--sx-bg-tertiary, #202024);
      stroke-width: 4;
    }

    .ring-fill {
      fill: none;
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .ring-fill.high { stroke: var(--sx-score-high, #22c55e); }
    .ring-fill.mid { stroke: var(--sx-score-mid, #eab308); }
    .ring-fill.low { stroke: var(--sx-score-low, #ef4444); }

    .score-value {
      position: absolute;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .score-number {
      font-weight: 700;
      line-height: 1;
      color: var(--sx-text-primary, #ededf0);
    }

    .score-max {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-weight: 500;
    }

    .score-label {
      font-size: 11px;
      font-weight: 500;
      color: var(--sx-text-secondary, #b4b4bc);
      text-align: center;
    }
  `;constructor(){super(),this.value=0,this.label="",this.size="md",this.animated=!0,this._displayValue=0}updated(e){e.has("value")&&(this.animated?this._animateValue():this._displayValue=this.value)}_animateValue(){let e=this._displayValue||0,t=this.value||0,s=700,i=performance.now(),a=o=>{let c=Math.min((o-i)/s,1);this._displayValue=Math.round(e+(t-e)*(1-Math.pow(1-c,3))),c<1&&requestAnimationFrame(a)};requestAnimationFrame(a)}_getColorClass(){return this.value>=71?"high":this.value>=41?"mid":"low"}_getDims(){switch(this.size){case"sm":return{s:56,r:22,f:14};case"lg":return{s:110,r:46,f:28};default:return{s:80,r:34,f:20}}}render(){let e=this._getDims(),t=2*Math.PI*e.r,s=t-t*(this.value||0)/100;return n`
      <div class="score-ring" style="width:${e.s}px;height:${e.s}px;">
        <svg width="${e.s}" height="${e.s}" viewBox="0 0 ${e.s} ${e.s}">
          <circle class="ring-bg" cx="${e.s/2}" cy="${e.s/2}" r="${e.r}"/>
          <circle class="ring-fill ${this._getColorClass()}" cx="${e.s/2}" cy="${e.s/2}" r="${e.r}" stroke-dasharray="${t}" stroke-dashoffset="${s}"/>
        </svg>
        <div class="score-value">
          <span class="score-number" style="font-size:${e.f}px">${this._displayValue}</span>
          <span class="score-max">/100</span>
        </div>
      </div>
      ${this.label?n`<span class="score-label">${this.label}</span>`:""}
    `}};customElements.define("synthux-score",ee);var te=class extends m{static properties={ollamaStatus:{type:Object},isAnalyzing:{type:Boolean},progress:{type:Object},pageInfo:{type:Object},selectedProfiles:{type:Array},mode:{type:String},logEntries:{type:Array},customProfiles:{type:Array},_showProfileForm:{type:Boolean,state:!0},_editingProfile:{type:Object,state:!0},_openMenuId:{type:String,state:!0},_selectedHeuristics:{type:Array,state:!0},_copiedCmd:{type:String,state:!0},_versionDismissed:{type:Boolean,state:!0},_showCorsWizard:{type:Boolean,state:!0},_checkingConnection:{type:Boolean,state:!0}};static styles=g`
    :host {
      display: block;
      padding: 16px;
    }

    /* ─── Page Info ──────────────────────────── */
    .page-info {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 10px;
      padding: 12px 14px;
      margin-bottom: 20px;
    }

    .page-title {
      font-size: 13px;
      font-weight: 600;
      color: var(--sx-text-primary, #ededf0);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 3px;
    }

    .page-url {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* ─── Section Headers ────────────────────── */
    .section-header {
      font-size: 11px;
      font-weight: 600;
      color: var(--sx-text-tertiary, #8a8a96);
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 10px;
    }

    /* ─── Profile Cards ──────────────────────── */
    .profiles {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-bottom: 20px;
    }

    .profile-card {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      cursor: pointer;
      transition: all 150ms ease;
      user-select: none;
    }

    .profile-card:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .profile-card.selected {
      border-color: var(--sx-accent, #3b82f6);
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
    }

    .profile-details {
      flex: 1;
      min-width: 0;
    }

    .profile-name {
      font-size: 13px;
      font-weight: 500;
      color: var(--sx-text-primary, #ededf0);
    }

    .profile-desc {
      font-size: 11px;
      color: var(--sx-text-secondary, #b4b4bc);
      margin-top: 1px;
    }

    .profile-check {
      width: 16px;
      height: 16px;
      border-radius: 4px;
      border: 1.5px solid var(--sx-border-hover, rgba(255,255,255,0.10));
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 150ms ease;
      font-size: 10px;
    }

    .profile-card.selected .profile-check {
      background: var(--sx-accent, #3b82f6);
      border-color: var(--sx-accent, #3b82f6);
      color: white;
    }

    .profile-card.selected .profile-check::after {
      content: '✓';
      font-weight: 700;
    }

    .profile-actions {
      position: relative;
      margin-left: 4px;
    }

    .kebab-btn {
      background: none;
      border: none;
      color: var(--sx-text-tertiary, #8a8a96);
      cursor: pointer;
      font-size: 16px;
      padding: 2px 6px;
      border-radius: 4px;
      transition: all 0.15s;
      line-height: 1;
      letter-spacing: 1px;
    }

    .kebab-btn:hover {
      background: var(--sx-bg-card-hover, rgba(255,255,255,0.05));
      color: var(--sx-text-primary, #ededf0);
    }

    .profile-dropdown {
      position: absolute;
      right: 0;
      top: 100%;
      margin-top: 4px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border-hover, rgba(255,255,255,0.10));
      border-radius: 8px;
      padding: 4px;
      min-width: 110px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.4);
      z-index: 10;
    }

    .dropdown-item {
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      padding: 7px 10px;
      background: none;
      border: none;
      border-radius: 5px;
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-family: inherit;
      cursor: pointer;
      transition: all 0.1s;
      text-align: left;
    }

    .dropdown-item:hover {
      background: var(--sx-bg-card-hover, rgba(255,255,255,0.05));
      color: var(--sx-text-primary, #ededf0);
    }

    .dropdown-item.danger:hover {
      background: rgba(239,68,68,0.1);
      color: #ef4444;
    }

    .add-profile-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10px 12px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px dashed var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      cursor: pointer;
      transition: all 150ms ease;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 12px;
      font-family: inherit;
    }

    .add-profile-btn:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .profile-form {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-accent, #3b82f6);
      border-radius: 8px;
      padding: 12px;
    }

    .pf-field { margin-bottom: 8px; }
    .pf-field:last-child { margin-bottom: 0; }

    .pf-label {
      display: block;
      font-size: 11px;
      font-weight: 500;
      color: var(--sx-text-secondary, #b4b4bc);
      margin-bottom: 3px;
    }

    .pf-hint {
      display: block;
      font-size: 10px;
      font-weight: 400;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-bottom: 4px;
    }

    .pf-input {
      width: 100%;
      padding: 6px 8px;
      background: var(--sx-bg-main, #121214);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      color: var(--sx-text-primary, #ededf0);
      font-size: 12px;
      font-family: inherit;
      box-sizing: border-box;
    }

    .pf-input:focus {
      outline: none;
      border-color: var(--sx-accent, #3b82f6);
    }

    .pf-row {
      display: flex;
      gap: 8px;
    }

    .pf-row > * { flex: 1; }

    .pf-checks {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 3px;
    }

    .pf-check-label {
      display: flex;
      align-items: center;
      gap: 3px;
      font-size: 11px;
      color: var(--sx-text-secondary, #b4b4bc);
      cursor: pointer;
    }

    .pf-actions {
      display: flex;
      gap: 6px;
      margin-top: 10px;
    }

    .pf-save {
      flex: 1;
      padding: 7px;
      background: var(--sx-accent, #3b82f6);
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
    }

    .pf-cancel {
      padding: 7px 12px;
      background: none;
      color: var(--sx-text-tertiary, #8a8a96);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      font-size: 12px;
      cursor: pointer;
      font-family: inherit;
    }

    /* ─── Mode Selector ──────────────────────── */
    .mode-selector {
      display: flex;
      gap: 6px;
      margin-bottom: 20px;
    }

    .mode-btn {
      flex: 1;
      padding: 9px;
      border-radius: 8px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-card, #1c1c1f);
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      text-align: center;
      font-family: inherit;
    }

    .mode-btn:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .mode-btn.active {
      border-color: var(--sx-accent, #3b82f6);
      color: var(--sx-text-primary, #ededf0);
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
    }

    .mode-label {
      font-size: 13px;
      font-weight: 600;
      display: block;
      margin-bottom: 2px;
    }

    .mode-desc {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-weight: 400;
    }

    /* ─── Analyze Button ─────────────────────── */
    .analyze-btn {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 8px;
      background: var(--sx-accent, #3b82f6);
      color: white;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .analyze-btn:hover:not(:disabled) {
      background: var(--sx-accent-hover, #60a5fa);
    }

    .analyze-btn:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }

    .analyze-btn.analyzing {
      background: var(--sx-bg-tertiary, #202024);
      color: var(--sx-text-secondary, #b4b4bc);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
    }

    /* ─── Flow Analysis Button ──────────────── */
    .flow-btn {
      width: 100%;
      margin-top: 10px;
      padding: 10px 14px;
      background: var(--sx-bg-tertiary, #202024);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      color: var(--sx-text-secondary, #b4b4bc);
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: space-between;
      transition: all 150ms ease;
    }

    .flow-btn:hover {
      border-color: var(--sx-accent, #3b82f6);
      background: rgba(59, 130, 246, 0.06);
      color: var(--sx-text-primary, #ededf0);
    }

    .flow-desc {
      font-size: 10px;
      font-weight: 400;
      color: var(--sx-text-tertiary, #8a8a96);
    }

    /* ─── Progress Display ───────────────────── */
    .progress-container {
      margin-top: 16px;
    }

    .progress-bar-wrapper {
      width: 100%;
      height: 3px;
      background: var(--sx-bg-tertiary, #202024);
      border-radius: 2px;
      overflow: hidden;
      margin-bottom: 10px;
    }

    .progress-bar-fill {
      height: 100%;
      background: var(--sx-accent, #3b82f6);
      border-radius: 2px;
      transition: width 400ms ease;
    }

    .cancel-btn {
      width: 100%;
      margin-top: 10px;
      padding: 7px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      background: transparent;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 11px;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .cancel-btn:hover {
      color: var(--sx-error, #ef4444);
      border-color: rgba(239, 68, 68, 0.3);
    }

    /* ─── Offline Notice ─────────────────────── */
    .offline-notice {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      padding: 10px 12px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      margin-bottom: 16px;
      font-size: 12px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
    }

    .offline-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--sx-warning, #eab308);
      flex-shrink: 0;
      margin-top: 6px;
    }

    /* ─── CORS Fix Wizard ──────────────────── */
    .cors-wizard {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid rgba(234, 179, 8, 0.25);
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 16px;
    }

    .cors-wizard-title {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 600;
      color: var(--sx-warning, #eab308);
      margin-bottom: 10px;
    }

    .cors-wizard-desc {
      font-size: 12px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
      margin-bottom: 12px;
    }

    .cors-steps {
      background: #0a0a0c;
      border: 1px solid rgba(255,255,255,0.06);
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
    }

    .cors-step-header {
      font-size: 11px;
      font-weight: 600;
      color: var(--sx-text-primary, #ededf0);
      margin-bottom: 10px;
    }

    .cors-platform {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
      border-bottom: 1px solid rgba(255,255,255,0.04);
    }

    .cors-platform:last-of-type {
      border-bottom: none;
    }

    .cors-platform-label {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      flex-shrink: 0;
      width: 55px;
    }

    .cors-cmd-block {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 10px;
      background: rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.06);
      border-radius: 6px;
      margin-top: 8px;
    }

    .cors-cmd-code {
      font-family: 'SF Mono', Monaco, 'Fira Code', monospace;
      font-size: 11px;
      color: var(--sx-text-primary, #ededf0);
      flex: 1;
      word-break: break-all;
      line-height: 1.4;
    }

    .cors-note {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 6px;
      line-height: 1.4;
    }

    .cors-other-platforms {
      margin-top: 10px;
      font-size: 11px;
    }

    .cors-other-platforms summary {
      color: var(--sx-text-tertiary, #8a8a96);
      cursor: pointer;
      font-size: 10px;
      padding: 4px 0;
    }

    .cors-other-platforms summary:hover {
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .cors-platform-alt {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 0;
      border-bottom: 1px solid rgba(255,255,255,0.04);
    }

    .cors-platform-alt:last-child {
      border-bottom: none;
    }

    .cors-copy-btn {
      background: var(--sx-bg-tertiary, #202024);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 4px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 10px;
      padding: 2px 8px;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.15s;
      flex-shrink: 0;
      margin-left: 6px;
    }

    .cors-copy-btn:hover {
      color: var(--sx-text-primary, #ededf0);
      border-color: rgba(255,255,255,0.15);
    }

    .cors-copy-btn.copied {
      color: var(--sx-success, #22c55e);
      border-color: rgba(34, 197, 94, 0.3);
    }

    .cors-check-btn {
      width: 100%;
      padding: 8px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      background: transparent;
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .cors-check-btn:hover {
      border-color: var(--sx-accent, #3b82f6);
      color: var(--sx-accent, #3b82f6);
    }

    /* ─── Version Banner ───────────────────── */
    .version-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 12px;
      background: rgba(249,115,22,0.06);
      border: 1px solid rgba(249,115,22,0.20);
      border-radius: 8px;
      margin-bottom: 16px;
      font-size: 12px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.4;
    }

    .version-banner-icon {
      font-size: 14px;
      flex-shrink: 0;
    }

    .version-banner-text {
      flex: 1;
    }

    .version-banner-actions {
      display: flex;
      gap: 6px;
      flex-shrink: 0;
    }

    .version-btn {
      padding: 3px 8px;
      border-radius: 4px;
      border: 1px solid rgba(255,255,255,0.08);
      background: transparent;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 10px;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.15s;
    }

    .version-btn:hover {
      color: var(--sx-text-primary, #ededf0);
    }

    .version-btn.fix {
      color: #f97316;
      border-color: rgba(249,115,22,0.3);
    }

    .version-btn.fix:hover {
      background: rgba(249,115,22,0.08);
    }

    .page-warning {
      font-size: 12px;
      color: var(--sx-text-tertiary, #8a8a96);
      text-align: center;
      padding: 8px;
      font-style: italic;
    }

    /* ─── Terminal Log ─────────────────────── */
    .terminal {
      margin-top: 12px;
      background: #0a0a0c;
      border: 1px solid rgba(255,255,255,0.06);
      border-radius: 8px;
      overflow: hidden;
    }

    .terminal-header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 10px;
      background: rgba(255,255,255,0.03);
      border-bottom: 1px solid rgba(255,255,255,0.04);
    }

    .terminal-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
    }

    .terminal-dot.red { background: #ff5f57; }
    .terminal-dot.yellow { background: #febc2e; }
    .terminal-dot.green { background: #28c840; }

    .terminal-title {
      flex: 1;
      text-align: center;
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-family: 'SF Mono', Monaco, monospace;
    }

    .terminal-body {
      padding: 8px 10px;
      max-height: 140px;
      overflow-y: auto;
      font-family: 'SF Mono', Monaco, 'Fira Code', monospace;
      font-size: 10px;
      line-height: 1.7;
    }

    .terminal-body::-webkit-scrollbar { width: 3px; }
    .terminal-body::-webkit-scrollbar-track { background: transparent; }
    .terminal-body::-webkit-scrollbar-thumb { background: #1a1a1e; border-radius: 3px; }

    .log-line {
      display: flex;
      gap: 6px;
      white-space: nowrap;
    }

    .log-time {
      color: #555;
      flex-shrink: 0;
    }

    .log-prefix {
      color: var(--sx-accent, #3b82f6);
      flex-shrink: 0;
    }

    .log-msg {
      color: #8b8b8b;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .log-msg.success { color: var(--sx-success, #22c55e); }
    .log-msg.active { color: var(--sx-text-primary, #ededf0); }
  `;constructor(){super(),this.ollamaStatus={connected:!1,models:[]},this.isAnalyzing=!1,this.progress=null,this.pageInfo=null,this.selectedProfiles=["first-time","power-user","accessibility"],this.mode="deep",this.logEntries=[],this.customProfiles=[],this._showProfileForm=!1,this._editingProfile=null,this._openMenuId=null,this._selectedHeuristics=[],this._copiedCmd=null,this._versionDismissed=!1,this._showCorsWizard=!1,this._checkingConnection=!1,this._fetchPageInfo(),this._loadCustomProfiles(),this._loadSettings(),chrome.tabs?.onActivated?.addListener(()=>this._fetchPageInfo()),chrome.tabs?.onUpdated?.addListener((e,t)=>{t.status==="complete"&&this._fetchPageInfo()}),window.addEventListener("profiles-changed",()=>this._loadCustomProfiles()),this._onDocClick=()=>{this._openMenuId=null},document.addEventListener("click",this._onDocClick)}async _loadSettings(){try{let e=await chrome.storage.local.get({synthux_selected_profiles:["first-time","power-user","accessibility"],synthux_selected_mode:"deep"});this.selectedProfiles=e.synthux_selected_profiles,this.mode=e.synthux_selected_mode,this.requestUpdate()}catch{}}updated(e){if(e.has("progress")&&this.progress&&this._addLogEntry(this.progress),e.has("isAnalyzing")){if(this.isAnalyzing)this.logEntries=[{time:this._logTime(),msg:"Starting analysis...",done:!1}];else if(this.logEntries.length>0){let s={...this.logEntries[this.logEntries.length-1],done:!0};this.logEntries=[...this.logEntries.slice(0,-1),s,{time:this._logTime(),msg:"Done.",done:!0}]}}let t=this.shadowRoot?.getElementById("terminal-log");t&&(t.scrollTop=t.scrollHeight)}_addLogEntry(e){let t=e.message||"";if(!t)return;let s=this.logEntries[this.logEntries.length-1];s&&s.msg===t||(this.logEntries=[...this.logEntries,{time:this._logTime(),msg:t,done:!1}])}_logTime(){let e=new Date;return`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}:${String(e.getSeconds()).padStart(2,"0")}`}get _isAnalyzablePage(){let e=this.pageInfo?.url||"";return!e.startsWith("http://")&&!e.startsWith("https://")?!1:!["chromewebstore.google.com","chrome.google.com/webstore","microsoftedge.microsoft.com/addons","addons.mozilla.org"].some(s=>e.includes(s))}get _isCloudProvider(){return(this.ollamaStatus?.provider||"ollama")!=="ollama"}get _allHeuristics(){return[{id:"visibility-of-system-status",name:{en:"Visibility of System Status"}},{id:"match-real-world",name:{en:"Match Real World"}},{id:"user-control-freedom",name:{en:"User Control & Freedom"}},{id:"consistency-standards",name:{en:"Consistency & Standards"}},{id:"error-prevention",name:{en:"Error Prevention"}},{id:"recognition-over-recall",name:{en:"Recognition > Recall"}},{id:"flexibility-efficiency",name:{en:"Flexibility & Efficiency"}},{id:"aesthetic-minimalist",name:{en:"Aesthetic & Minimalist"}},{id:"error-recovery",name:{en:"Error Recovery"}},{id:"help-documentation",name:{en:"Help & Documentation"}}]}_toggleHeuristic(e){if(this.isAnalyzing)return;let t=[...this._selectedHeuristics],s=t.indexOf(e);s>-1?t.splice(s,1):t.push(e),this._selectedHeuristics=t}_estimateTime(e){let t=this.selectedProfiles?.length||1,s=this._isCloudProvider?.5:4,i=Math.round(e*t*s);return i<1?"<1 min":i>=60?`${Math.round(i/60)}h ${i%60}min`:`${i} min`}async _fetchPageInfo(){if(!this.isAnalyzing)try{let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});e&&(this.pageInfo={title:e.title||"Untitled",url:e.url||""})}catch{this.pageInfo={title:"Unable to detect page",url:""}}}async _loadCustomProfiles(){try{this.customProfiles=await A()}catch{this.customProfiles=[]}}_toggleProfile(e){if(this.isAnalyzing)return;let t=[...this.selectedProfiles],s=t.indexOf(e);s>-1?t.length>1&&t.splice(s,1):t.push(e),this.selectedProfiles=t,chrome.storage.local.set({synthux_selected_profiles:t})}_setMode(e){this.isAnalyzing||(this.mode=e,chrome.storage.local.set({synthux_selected_mode:e}))}async _startAnalysis(){if(!(this.isAnalyzing||!this.ollamaStatus?.connected)){this.dispatchEvent(new CustomEvent("analysis-start"));try{await chrome.runtime.sendMessage({type:"START_ANALYSIS",payload:{mode:this.mode,profiles:this.selectedProfiles,...this.mode==="custom"&&this._selectedHeuristics.length>0?{heuristics:this._selectedHeuristics}:{}}})}catch(e){console.error("[synthux] Failed to start analysis:",e),this.dispatchEvent(new CustomEvent("analysis-end"))}}}async _cancelAnalysis(){try{await chrome.runtime.sendMessage({type:"CANCEL_ANALYSIS"})}catch{}this.dispatchEvent(new CustomEvent("analysis-end"))}_renderProfileCard(e,t,s,i=!1){let a=this.selectedProfiles.includes(e);return n`
      <div 
        class="profile-card ${a?"selected":""}"
        @click="${()=>this._toggleProfile(e)}"
        role="checkbox"
        aria-checked="${a}"
        tabindex="0"
        @keydown="${o=>o.key==="Enter"&&this._toggleProfile(e)}"
      >
        <div class="profile-details">
          <div class="profile-name">${t}${i?n`<span style="font-size: 9px; background: var(--sx-blue-dim, rgba(0,126,255,0.1)); color: var(--sx-blue, #007eff); padding: 1px 6px; border-radius: 8px; margin-left: 6px; font-weight: 600; vertical-align: middle;">Custom</span>`:""}</div>
          <div class="profile-desc">${s}</div>
        </div>
        ${i?n`
          <div class="profile-actions">
            <button class="kebab-btn" @click="${o=>{o.stopPropagation(),this._openMenuId=this._openMenuId===e?null:e}}" title="Options">⋮</button>
            ${this._openMenuId===e?n`
              <div class="profile-dropdown">
                <button class="dropdown-item" @click="${o=>{o.stopPropagation(),this._openMenuId=null,this._editProfile(e)}}">✎ Edit</button>
                <button class="dropdown-item danger" @click="${o=>{o.stopPropagation(),this._openMenuId=null,this._removeProfile(e)}}">✕ Delete</button>
              </div>
            `:""}
          </div>
        `:""}
        <div class="profile-check"></div>
      </div>
    `}_renderProfileForm(){let e=this._editingProfile;return n`
      <div class="profile-form">
        <div class="pf-field">
          <label class="pf-label">Persona Name *</label>
          <span class="pf-hint">Give this synthetic user a name</span>
          <input type="text" class="pf-input" id="pf-name" placeholder="e.g. Senior Executive" maxlength="40" .value="${e?.name?.en||""}" />
        </div>
        <div class="pf-row">
          <div class="pf-field">
            <label class="pf-label">Age Range</label>
            <select class="pf-input" id="pf-age">
              ${["18-25","25-35","35-50","50-65","65+"].map(t=>n`<option value="${t}" ?selected="${(e?.ageRange||"25-35")===t}">${t}</option>`)}
            </select>
          </div>
          <div class="pf-field">
            <label class="pf-label">Tech Savviness</label>
            <select class="pf-input" id="pf-tech">
              ${["low","medium","high"].map(t=>n`<option value="${t}" ?selected="${(e?.techLevel||"medium")===t}">${t==="low"?"Low \u2014 basic user":t==="medium"?"Medium \u2014 regular":"High \u2014 power user"}</option>`)}
            </select>
          </div>
        </div>
        <div class="pf-field">
          <label class="pf-label">Accessibility Needs</label>
          <span class="pf-hint">Does this persona have any disabilities?</span>
          <div class="pf-checks">
            ${[["vision","Low Vision"],["hearing","Hearing"],["motor","Motor"],["cognitive","Cognitive"]].map(([t,s])=>n`
              <label class="pf-check-label">
                <input type="checkbox" class="pf-disability" value="${t}" ?checked="${(e?.disabilities||[]).includes(t)}" />
                ${s}
              </label>
            `)}
          </div>
        </div>
        <div class="pf-field">
          <label class="pf-label">Goal</label>
          <span class="pf-hint">What is this person trying to do on the page?</span>
          <input type="text" class="pf-input" id="pf-goal" placeholder="e.g. Find pricing and compare plans" maxlength="100" .value="${e?.goal||""}" />
        </div>
        <div class="pf-actions">
          <button class="pf-save" @click="${this._handleSaveProfile}">${e?"Update":"Create"}</button>
          <button class="pf-cancel" @click="${()=>{this._showProfileForm=!1,this._editingProfile=null}}">Cancel</button>
        </div>
      </div>
    `}_editProfile(e){let t=this.customProfiles.find(s=>s.id===e);t&&(this._editingProfile=t,this._showProfileForm=!0)}async _removeProfile(e){try{await I(e),this.selectedProfiles=this.selectedProfiles.filter(t=>t!==e),await this._loadCustomProfiles()}catch(t){console.error("[synthux] Failed to delete profile:",t)}}async _handleSaveProfile(){let e=this.shadowRoot.getElementById("pf-name")?.value?.trim();if(!e)return;let t=this.shadowRoot.getElementById("pf-age")?.value||"25-35",s=this.shadowRoot.getElementById("pf-tech")?.value||"medium",i=this.shadowRoot.getElementById("pf-goal")?.value?.trim()||"",a=Array.from(this.shadowRoot.querySelectorAll(".pf-disability:checked")).map(o=>o.value);try{this._editingProfile&&await I(this._editingProfile.id);let o=await j({name:e,description:`${t}, ${s} tech${i?` \u2014 ${i}`:""}`,ageRange:t,techLevel:s,disabilities:a,goal:i,priorityHeuristics:[]});if(this._editingProfile){let c=this.selectedProfiles.indexOf(this._editingProfile.id);if(c>-1){let l=[...this.selectedProfiles];l[c]=o.id,this.selectedProfiles=l}}this._showProfileForm=!1,this._editingProfile=null,await this._loadCustomProfiles()}catch(o){console.error("[synthux] Failed to save profile:",o)}}render(){let e=this.ollamaStatus?.connected,t=this.mode!=="custom"||this._selectedHeuristics.length>0,s=e&&this._isAnalyzablePage&&this.selectedProfiles.length>0&&t;return n`
      ${this.pageInfo?n`
        <div class="page-info">
          <div class="page-title">${this.pageInfo.title}</div>
          <div class="page-url">${this.pageInfo.url}</div>
          ${!this._isAnalyzablePage&&this.pageInfo.url?n`
            <div class="page-warning">Navigate to a website to analyze.</div>
          `:""}
        </div>
      `:""}

      ${this.ollamaStatus?.corsBlocked||this._showCorsWizard?this._renderCorsWizard():""}

      ${!e&&!this.ollamaStatus?.corsBlocked?n`
        <div class="offline-notice">
          <span class="offline-dot"></span>
          <div>
            <strong>AI not connected.</strong> Check Settings to configure your AI provider.
          </div>
        </div>
      `:""}

      ${this.ollamaStatus?.versionChanged&&!this._versionDismissed&&!this.ollamaStatus?.corsBlocked?n`
        <div class="version-banner">
          <span class="version-banner-icon" style="font-size: 14px;">i</span>
          <div class="version-banner-text">
            Ollama updated <strong>${this.ollamaStatus.oldVersion} → ${this.ollamaStatus.newVersion}</strong>.<br>
            If analysis fails, CORS may need reconfiguration.
          </div>
          <div class="version-banner-actions">
            <button class="version-btn fix" @click="${()=>{this._showCorsWizard=!0}}">Fix Now</button>
            <button class="version-btn" @click="${()=>{this._versionDismissed=!0}}">Dismiss</button>
          </div>
        </div>
      `:""}

      <div class="section-header">Profiles</div>
      <div class="profiles">
        ${this._renderProfileCard("first-time","First-Time Visitor","New to the site, exploring for the first time")}
        ${this._renderProfileCard("power-user","Power User","Experienced, focused on speed and efficiency")}
        ${this._renderProfileCard("accessibility","Accessibility User","Relies on screen reader and keyboard")}
        ${this.customProfiles.map(i=>this._renderProfileCard(i.id,`${i.name.en}`,i.description?.en||"Custom profile",!0))}
        ${this._showProfileForm?this._renderProfileForm():n`
          ${this.customProfiles.length<5?n`
            <button class="add-profile-btn" @click="${()=>{this._editingProfile=null,this._showProfileForm=!0}}">+ Add Custom Profile</button>
          `:""}
        `}
      </div>

      <div class="section-header">Mode</div>
      <div class="mode-selector">
        <button class="mode-btn ${this.mode==="quick"?"active":""}" @click="${()=>this._setMode("quick")}">
          <span class="mode-label">Quick</span>
          <span class="mode-desc">3 heuristics · ~${this._estimateTime(3)}</span>
        </button>
        <button class="mode-btn ${this.mode==="deep"?"active":""}" @click="${()=>this._setMode("deep")}">
          <span class="mode-label">Deep</span>
          <span class="mode-desc">10 heuristics · ~${this._estimateTime(10)}</span>
        </button>
        <button class="mode-btn ${this.mode==="custom"?"active":""}" @click="${()=>this._setMode("custom")}">
          <span class="mode-label">Custom</span>
          <span class="mode-desc">${this._selectedHeuristics.length||0} selected${this._selectedHeuristics.length>0?` \xB7 ~${this._estimateTime(this._selectedHeuristics.length)}`:""}</span>
        </button>
      </div>

      ${this.mode==="custom"?n`
        <div style="display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 16px;">
          ${this._allHeuristics.map(i=>{let a=this._selectedHeuristics.includes(i.id);return n`
              <button
                style="
                  padding: 4px 10px; font-size: 11px; border-radius: 12px; cursor: pointer;
                  font-family: inherit; transition: all 0.15s; border: 1px solid;
                  background: ${a?"var(--sx-accent-dim, rgba(59,130,246,0.1))":"var(--sx-bg-card, #1c1c1f)"};
                  border-color: ${a?"var(--sx-accent, #3b82f6)":"var(--sx-border, rgba(255,255,255,0.06))"};
                  color: ${a?"var(--sx-accent, #3b82f6)":"var(--sx-text-tertiary, #8a8a96)"};
                "
                @click="${()=>this._toggleHeuristic(i.id)}"
              >${i.name?.en||i.id}</button>
            `})}
        </div>
      `:""}

      ${this.isAnalyzing?n`
        <button class="analyze-btn analyzing" disabled>Analyzing...</button>
      `:n`
        <button 
          class="analyze-btn"
          ?disabled="${!s}"
          @click="${this._startAnalysis}"
        >Analyze Page</button>
      `}

      ${this.isAnalyzing&&this.progress?n`
        <div class="progress-container">
          <div class="progress-bar-wrapper">
            <div class="progress-bar-fill" style="width: ${this.progress.percent||0}%"></div>
          </div>

          <div class="terminal">
            <div class="terminal-header">
              <span class="terminal-title">synthux — analysis</span>
            </div>
            <div class="terminal-body" id="terminal-log">
              ${this.logEntries.map((i,a)=>n`
                <div class="log-line">
                  <span class="log-time">${i.time}</span>
                  <span class="log-prefix">▶</span>
                  <span class="log-msg ${a===this.logEntries.length-1?"active":""} ${i.done?"success":""}">${i.msg}</span>
                </div>
              `)}
            </div>
          </div>

          <button class="cancel-btn" @click="${this._cancelAnalysis}">Cancel</button>
        </div>
      `:""}

      <div class="section-header" style="margin-top: 20px;">Beta Features</div>
      <button
        class="flow-btn"
        @click="${this._openFlowBuilder}"
      >
        <span style="display:flex;align-items:center;gap:6px;">
          <span>Flow Analysis</span>
        </span>
        <span class="flow-desc">Multi-page canvas builder</span>
      </button>
    `}_openFlowBuilder(){let e=this.pageInfo?.url||"",t=this.pageInfo?.title||"",s=chrome.runtime.getURL("flow/index.html");e&&(e.startsWith("http://")||e.startsWith("https://"))&&(s+=`?url=${encodeURIComponent(e)}&title=${encodeURIComponent(t)}`),chrome.tabs.create({url:s})}async _copyCmd(e,t){try{await navigator.clipboard.writeText(e),this._copiedCmd=t,setTimeout(()=>{this._copiedCmd=null},2e3)}catch{this._copiedCmd=t,setTimeout(()=>{this._copiedCmd=null},2e3)}}async _checkConnection(){this._checkingConnection=!0;try{(await chrome.runtime.sendMessage({type:"CHECK_CONNECTION"}))?.connected&&(this._showCorsWizard=!1,this.dispatchEvent(new CustomEvent("connection-fixed",{bubbles:!0,composed:!0})))}catch{}this._checkingConnection=!1}_renderCorsWizard(){let e=this._detectPlatform(),t=e.cmd,s=this._checkingConnection;return n`
      <div class="cors-wizard">
        <div class="cors-wizard-title">
          Ollama CORS Configuration Required
        </div>
        <div class="cors-wizard-desc">
          Ollama is running but blocking requests from this extension.
          Run the command below, then restart Ollama.
        </div>
        <div class="cors-steps">
          <div class="cors-step-header">Step 1 — Run in Terminal</div>
          <div class="cors-cmd-block">
            <code class="cors-cmd-code">${t}</code>
            <button
              class="cors-copy-btn ${this._copiedCmd?"copied":""}"
              @click="${()=>this._copyCmd(t,"main")}"
            >${this._copiedCmd?"Copied":"Copy"}</button>
          </div>
          ${e.note?n`<div class="cors-note">${e.note}</div>`:""}
          <div class="cors-step-header" style="margin-top: 14px;">Step 2 — Quit and restart Ollama</div>
          <div class="cors-note">Close Ollama completely (menu bar → Quit Ollama), then open it again. The setting won't take effect until Ollama is restarted.</div>
        </div>
        <button
          class="cors-check-btn"
          ?disabled="${s}"
          @click="${this._checkConnection}"
        >${s?"Checking...":"Check Connection"}</button>
        ${e.others.length>0?n`
          <details class="cors-other-platforms">
            <summary>Other platforms</summary>
            ${e.others.map(i=>n`
              <div class="cors-platform-alt">
                <span class="cors-platform-label">${i.name}</span>
                <code class="cors-platform-cmd">${i.cmd}</code>
                <button
                  class="cors-copy-btn ${this._copiedCmd===i.id?"copied":""}"
                  @click="${()=>this._copyCmd(i.cmd,i.id)}"
                >${this._copiedCmd===i.id?"Copied":"Copy"}</button>
              </div>
            `)}
          </details>
        `:""}
      </div>
    `}_detectPlatform(){let e=navigator.userAgent.toLowerCase(),t=e.includes("mac"),s=e.includes("win"),i={mac:{name:"macOS",id:"macos",cmd:'launchctl setenv OLLAMA_ORIGINS "*"',note:null},linux:{name:"Linux",id:"linux",cmd:"sudo systemctl edit ollama",note:'Add this line under [Service]: Environment="OLLAMA_ORIGINS=*"'},win:{name:"Windows",id:"win",cmd:'[Environment]::SetEnvironmentVariable("OLLAMA_ORIGINS", "*", "User")',note:"Run in PowerShell as Administrator"}},a,o;return t?(a=i.mac,o=[i.linux,i.win]):s?(a=i.win,o=[i.mac,i.linux]):(a=i.linux,o=[i.mac,i.win]),{...a,others:o}}};customElements.define("synthux-scanner",te);var se=class extends m{static properties={report:{type:Object},history:{type:Array},showHistory:{type:Boolean},activeProfile:{type:String},expandedHeuristic:{type:String},copied:{type:Boolean},activeFilter:{type:String},copiedFix:{type:String},heatmapActive:{type:Boolean}};static styles=g`
    :host {
      display: block;
      padding: 16px;
    }

    /* ─── Empty State ────────────────────────── */
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 48px 24px;
      text-align: center;
    }

    .empty-title {
      font-size: 14px;
      font-weight: 600;
      color: var(--sx-text-secondary, #b4b4bc);
      margin-bottom: 4px;
    }

    .empty-desc {
      font-size: 12px;
      color: var(--sx-text-tertiary, #8a8a96);
    }

    /* ─── Overall Score ──────────────────────── */
    .overall-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px 0;
      margin-bottom: 16px;
    }

    .report-meta {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 10px;
      text-align: center;
      line-height: 1.6;
    }

    /* ─── Profile Tabs ───────────────────────── */
    .profile-tabs {
      display: flex;
      gap: 4px;
      margin-bottom: 16px;
      overflow-x: auto;
    }

    .profile-tab {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 7px 12px;
      border-radius: 6px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-card, #1c1c1f);
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      white-space: nowrap;
      font-family: inherit;
    }

    .profile-tab:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .profile-tab.active {
      border-color: var(--sx-accent, #3b82f6);
      color: var(--sx-text-primary, #ededf0);
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
    }

    .profile-tab-score {
      font-weight: 700;
      font-size: 11px;
    }

    /* ─── Section Header ─────────────────────── */
    .section-header {
      font-size: 11px;
      font-weight: 600;
      color: var(--sx-text-tertiary, #8a8a96);
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 10px;
      margin-top: 8px;
    }

    /* ─── Heuristic Cards ────────────────────── */
    .heuristic-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-bottom: 20px;
    }

    .heuristic-card {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      overflow: hidden;
      transition: border-color 150ms ease;
    }

    .heuristic-card:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .heuristic-header {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      cursor: pointer;
      user-select: none;
    }

    .heuristic-score-badge {
      min-width: 36px;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      text-align: center;
    }

    .heuristic-score-badge.high {
      background: var(--sx-success-dim, rgba(34,197,94,0.10));
      color: var(--sx-success, #22c55e);
    }

    .heuristic-score-badge.mid {
      background: var(--sx-warning-dim, rgba(234,179,8,0.10));
      color: var(--sx-warning, #eab308);
    }

    .heuristic-score-badge.low {
      background: var(--sx-error-dim, rgba(239,68,68,0.10));
      color: var(--sx-error, #ef4444);
    }

    .heuristic-name {
      flex: 1;
      font-size: 12px;
      font-weight: 500;
      color: var(--sx-text-primary, #ededf0);
    }

    .heuristic-chevron {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      transition: transform 150ms ease;
    }

    .heuristic-chevron.open {
      transform: rotate(90deg);
    }

    .heuristic-detail {
      padding: 0 12px 12px;
      border-top: 1px solid var(--sx-border, rgba(255,255,255,0.04));
    }

    .heuristic-summary {
      font-size: 12px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
      padding-top: 10px;
      margin-bottom: 10px;
    }

    /* ─── Issues ──────────────────────────────── */
    .issue-item {
      display: flex;
      gap: 8px;
      padding: 8px 4px;
      border-bottom: 1px solid var(--sx-border, rgba(255,255,255,0.04));
      border-radius: 4px;
      cursor: pointer;
      transition: background 150ms ease;
    }

    .issue-item:hover {
      background: rgba(59, 130, 246, 0.06);
    }

    .issue-item:last-child { border-bottom: none; }

    /* ─── Heatmap Toggle ────────────────────────── */
    .heatmap-toggle {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      margin: 0 0 14px;
    }

    .heatmap-label {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-weight: 500;
    }

    .heatmap-switch {
      position: relative;
      width: 36px;
      height: 20px;
      background: var(--sx-border, rgba(255,255,255,0.08));
      border-radius: 10px;
      cursor: pointer;
      transition: background 200ms ease;
      border: none;
      padding: 0;
    }

    .heatmap-switch::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 2px;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: var(--sx-text-tertiary, #8a8a96);
      transition: transform 200ms ease, background 200ms ease;
    }

    .heatmap-switch.active {
      background: rgba(239, 68, 68, 0.25);
    }

    .heatmap-switch.active::after {
      transform: translateX(16px);
      background: #ef4444;
    }

    .severity-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      margin-top: 6px;
    }

    .severity-dot.critical { background: var(--sx-error, #ef4444); }
    .severity-dot.moderate { background: var(--sx-warning, #eab308); }
    .severity-dot.minor { background: var(--sx-success, #22c55e); }

    .issue-content { flex: 1; }

    .issue-desc {
      font-size: 12px;
      color: var(--sx-text-primary, #ededf0);
      line-height: 1.4;
    }

    .issue-recommendation {
      font-size: 11px;
      color: var(--sx-accent, #3b82f6);
      margin-top: 3px;
      line-height: 1.4;
    }

    .issue-element {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 2px;
      font-family: 'SF Mono', Monaco, monospace;
    }

    /* ─── Code Fix Block ──────────────────────── */
    .code-fix-block {
      margin-top: 6px;
      border-radius: 6px;
      overflow: hidden;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
    }

    .code-fix-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 4px 8px;
      background: rgba(59,130,246,0.08);
      font-size: 10px;
      color: var(--sx-accent, #3b82f6);
    }

    .code-fix-copy {
      padding: 2px 6px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.08));
      border-radius: 3px;
      background: transparent;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 9px;
      cursor: pointer;
      font-family: inherit;
      transition: all 150ms ease;
    }

    .code-fix-copy:hover {
      color: var(--sx-accent, #3b82f6);
      border-color: var(--sx-accent, #3b82f6);
    }

    .code-fix-copy.copied {
      color: var(--sx-success, #22c55e);
      border-color: rgba(34,197,94,0.3);
    }

    .code-fix-pre {
      padding: 8px;
      background: rgba(0,0,0,0.3);
      font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
      font-size: 11px;
      line-height: 1.5;
      color: var(--sx-text-secondary, #b4b4bc);
      white-space: pre-wrap;
      word-break: break-all;
      margin: 0;
    }

    .code-fix-label {
      font-size: 9px;
      color: var(--sx-text-tertiary, #8a8a96);
      padding: 2px 8px 0;
      background: rgba(0,0,0,0.3);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .code-fix-label:first-of-type { padding-top: 4px; }

    /* ─── Priority Badge ──────────────────────── */
    .priority-badge {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      padding: 1px 5px;
      border-radius: 3px;
      font-size: 9px;
      font-weight: 600;
      margin-left: 4px;
      letter-spacing: 0.3px;
    }

    .priority-badge.quick-win {
      background: rgba(234,179,8,0.12);
      color: #eab308;
    }

    .priority-badge.high {
      background: var(--sx-error-dim, rgba(239,68,68,0.10));
      color: var(--sx-error, #ef4444);
    }

    .effort-tag {
      display: inline-flex;
      align-items: center;
      padding: 1px 4px;
      border-radius: 3px;
      font-size: 9px;
      margin-left: 3px;
    }

    .effort-tag.easy {
      background: var(--sx-success-dim, rgba(34,197,94,0.10));
      color: var(--sx-success, #22c55e);
    }

    .effort-tag.hard {
      background: var(--sx-error-dim, rgba(239,68,68,0.10));
      color: var(--sx-text-tertiary, #8a8a96);
    }

    /* ─── Filter Bar ─────────────────────────── */
    .filter-bar {
      display: flex;
      gap: 4px;
      margin-bottom: 12px;
      overflow-x: auto;
    }

    .filter-btn {
      padding: 4px 10px;
      border-radius: 12px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: transparent;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 10px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
      white-space: nowrap;
    }

    .filter-btn:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .filter-btn.active {
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
      border-color: var(--sx-accent, #3b82f6);
      color: var(--sx-accent, #3b82f6);
    }

    .filter-count {
      font-weight: 700;
    }

    /* ─── Positives ──────────────────────────── */
    .positive-item {
      display: flex;
      align-items: flex-start;
      gap: 6px;
      padding: 3px 0;
      font-size: 12px;
      color: var(--sx-success, #22c55e);
    }

    .positive-dot {
      width: 4px;
      height: 4px;
      border-radius: 50%;
      background: var(--sx-success, #22c55e);
      flex-shrink: 0;
      margin-top: 6px;
    }

    /* ─── Accessibility Audit ────────────────── */
    .a11y-section { margin-bottom: 20px; }

    .a11y-card {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      overflow: hidden;
    }

    .a11y-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
    }

    .a11y-title {
      font-size: 12px;
      font-weight: 500;
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .a11y-score-badge {
      font-size: 11px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 4px;
    }

    .a11y-check {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 7px 12px;
      border-top: 1px solid var(--sx-border, rgba(255,255,255,0.04));
      font-size: 12px;
    }

    .check-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .check-dot.pass { background: var(--sx-success, #22c55e); }
    .check-dot.warning { background: var(--sx-warning, #eab308); }
    .check-dot.fail { background: var(--sx-error, #ef4444); }

    .a11y-name {
      flex: 1;
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .a11y-message {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      max-width: 45%;
      text-align: right;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* ─── Export Button ───────────────────────── */
    .export-bar {
      position: sticky;
      bottom: 0;
      padding: 12px 0;
      background: linear-gradient(transparent, var(--sx-bg-primary, #111113) 25%);
    }

    .export-btn {
      width: 100%;
      padding: 9px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      background: var(--sx-bg-card, #1c1c1f);
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .export-btn:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
      color: var(--sx-text-primary, #ededf0);
    }

    .export-btn.copied {
      color: var(--sx-success, #22c55e);
      border-color: rgba(34, 197, 94, 0.2);
    }

    .export-actions {
      display: flex;
      gap: 6px;
    }

    .export-actions .export-btn {
      flex: 1;
    }

    .export-btn.pdf {
      border-color: rgba(59,130,246,0.2);
      color: var(--sx-accent, #3b82f6);
    }

    .export-btn.pdf:hover {
      background: rgba(59,130,246,0.06);
    }

    /* ─── History List ────────────────────────── */
    .history-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .history-item {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      cursor: pointer;
      transition: all 150ms ease;
    }

    .history-item:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .history-score {
      min-width: 36px;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
    }

    .history-score.high {
      background: var(--sx-success-dim);
      color: var(--sx-success);
    }
    .history-score.mid {
      background: var(--sx-warning-dim);
      color: var(--sx-warning);
    }
    .history-score.low {
      background: var(--sx-error-dim);
      color: var(--sx-error);
    }

    .history-details {
      flex: 1;
      min-width: 0;
    }

    .history-title {
      font-size: 12px;
      font-weight: 500;
      color: var(--sx-text-primary, #ededf0);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .history-meta {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 1px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .history-delete {
      width: 24px;
      height: 24px;
      border-radius: 4px;
      border: none;
      background: transparent;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 150ms ease;
      flex-shrink: 0;
    }

    .history-delete:hover {
      color: var(--sx-error, #ef4444);
      background: var(--sx-error-dim, rgba(239,68,68,0.10));
    }

    .history-empty {
      text-align: center;
      padding: 32px 16px;
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 12px;
    }
  `;constructor(){super(),this.report=null,this.history=[],this.showHistory=!1,this.activeProfile="",this.expandedHeuristic="",this.copied=!1,this.activeFilter="all",this.copiedFix="",this.heatmapActive=!1}updated(e){if(e.has("report")&&this.report){let t=Object.keys(this.report.profileResults||{});t.length>0&&!this.activeProfile&&(this.activeProfile=t[0])}}_toggleHeuristic(e){this.expandedHeuristic=this.expandedHeuristic===e?"":e}_highlightIssue(e){e.element&&chrome.runtime.sendMessage({type:"HIGHLIGHT_ELEMENT",payload:{selector:e.element,description:e.description,severity:e.severity}}).catch(()=>{})}_clearHighlight(){chrome.runtime.sendMessage({type:"CLEAR_HIGHLIGHT",payload:{}}).catch(()=>{})}_toggleHeatmap(){if(this.heatmapActive=!this.heatmapActive,this.heatmapActive){let e=[];Object.values(this.report?.profileResults||{}).forEach(t=>{(t.evaluations||[]).forEach(s=>{(s.issues||[]).forEach(i=>{i.element&&e.push({element:i.element,severity:i.severity,description:i.description})})})}),chrome.runtime.sendMessage({type:"SHOW_HEATMAP",payload:{issues:e}}).catch(()=>{})}else chrome.runtime.sendMessage({type:"CLEAR_HEATMAP",payload:{}}).catch(()=>{})}disconnectedCallback(){super.disconnectedCallback(),chrome.runtime.sendMessage({type:"CLEAR_OVERLAYS",payload:{}}).catch(()=>{})}_getScoreClass(e){return e>=71?"high":e>=41?"mid":"low"}_downloadMarkdown(){if(!this.report?.markdown)return;let t=`design-change-${this._shortenUrl(this.report.url).replace(/[\/:.]/g,"-").replace(/-+/g,"-")}.md`,s=new Blob([this.report.markdown],{type:"text/markdown;charset=utf-8"}),i=URL.createObjectURL(s),a=document.createElement("a");a.href=i,a.download=t,a.click(),URL.revokeObjectURL(i),this.copied=!0,setTimeout(()=>{this.copied=!1},2e3)}async _downloadPDF(){if(this.report)try{let{generatePDF:e}=await import("./chunks/pdf-export-TVSCPTEW.js"),t=e(this.report),i=`synthux-report-${this._shortenUrl(this.report.url).replace(/[\/:.]/g,"-").replace(/-+/g,"-")}.pdf`,a=URL.createObjectURL(t),o=document.createElement("a");o.href=a,o.download=i,o.click(),URL.revokeObjectURL(a)}catch(e){console.error("[synthux] PDF generation failed:",e)}}render(){if(this.showHistory)return this._renderHistory();if(!this.report)return n`
        <div class="empty-state">
          <div class="empty-title">No report yet</div>
          <div class="empty-desc">Go to Scan tab to analyze a page.</div>
        </div>
      `;let e=this.report,t=e.profileResults?.[this.activeProfile];return n`
      <div class="overall-section">
        <synthux-score value="${e.overallScore||0}" label="Overall UX Score" size="lg"></synthux-score>
        <div class="report-meta">
          ${this._shortenUrl(e.url)}${e.model?n`<br>${e.model} · `:""}${e.mode==="deep"?"Deep":"Quick"}
          ${e.timestamp?n` · ${new Date(e.timestamp).toLocaleString()}`:""}
          ${e.costSummary?n`<br><span style="color: ${e.costSummary.isLocal?"var(--sx-success, #22c55e)":"var(--sx-warning, #eab308)"}">${e.costSummary.formatted}</span>`:""}
        </div>
      </div>

      <div class="heatmap-toggle">
        <span class="heatmap-label">Heatmap</span>
        <button class="heatmap-switch ${this.heatmapActive?"active":""}" 
          @click="${this._toggleHeatmap}" 
          title="${this.heatmapActive?"Heatmap is ON \u2014 click to hide":"Show issue heatmap on page"}">
        </button>
      </div>

      <div class="profile-tabs">
        ${Object.entries(e.profileResults||{}).map(([s,i])=>n`
          <button class="profile-tab ${this.activeProfile===s?"active":""}" @click="${()=>this.activeProfile=s}" title="${i.profile.custom?`${i.profile.ageRange||""} \xB7 ${i.profile.techLevel||""} tech${i.profile.goal?` \xB7 ${i.profile.goal}`:""}`:i.profile.description?.en||""}">
            <span>${i.profile.name?.en||s}${i.profile.custom?n`<span style="font-size: 8px; background: rgba(0,126,255,0.1); color: #007eff; padding: 0 4px; border-radius: 4px; margin-left: 4px; vertical-align: middle;">C</span>`:""}</span>
            <span class="profile-tab-score">${i.score}</span>
          </button>
        `)}
      </div>

      ${t?n`
        ${this._renderFilterBar(t)}
        <div class="section-header">Evaluations</div>
        <div class="heuristic-list">
          ${(t.evaluations||[]).map(s=>{let i=this._filterIssues(s.issues||[]);if(this.activeFilter!=="all"&&i.length===0)return"";let a=this.activeFilter!=="all"||this.expandedHeuristic===s.heuristicId;return n`
            <div class="heuristic-card">
              <div class="heuristic-header" @click="${()=>this._toggleHeuristic(s.heuristicId)}">
                <span class="heuristic-score-badge ${this._getScoreClass(s.score)}">${s.score}</span>
                <span class="heuristic-name">${s.heuristicName?.en||s.heuristicId}</span>
                <span class="heuristic-chevron ${a?"open":""}">▶</span>
              </div>
              ${a?n`
                <div class="heuristic-detail">
                  <div class="heuristic-summary">${s.summary}</div>
                  ${i.map(o=>n`
                    <div class="issue-item"
                      @mouseenter="${()=>this._highlightIssue(o)}"
                      @mouseleave="${()=>this._clearHighlight()}">
                      <span class="severity-dot ${o.severity}"></span>
                      <div class="issue-content">
                        <div class="issue-desc">
                          ${o.description}
                          ${o.isQuickWin?n`<span class="priority-badge quick-win">⚡ Quick Win</span>`:o.priority==="high"?n`<span class="priority-badge high">HIGH</span>`:""}
                          ${o.fixEffort==="easy"?n`<span class="effort-tag easy">Easy fix</span>`:o.fixEffort==="hard"?n`<span class="effort-tag hard">Hard</span>`:""}
                        </div>
                        ${o.element?n`<div class="issue-element">${o.element}</div>`:""}
                        ${o.recommendation?n`<div class="issue-recommendation">${o.recommendation}</div>`:""}
                        ${o.codeFix?n`
                          <div class="code-fix-block">
                            <div class="code-fix-header">
                              <span>${o.codeFix.language.toUpperCase()} fix</span>
                              <button class="code-fix-copy ${this.copiedFix===o.element?"copied":""}" 
                                @click="${c=>{c.stopPropagation(),this._copyFix(o)}}">
                                ${this.copiedFix===o.element?"Copied \u2713":"Copy"}
                              </button>
                            </div>
                            ${o.codeFix.before?n`
                              <div class="code-fix-label">Before</div>
                              <pre class="code-fix-pre">${o.codeFix.before}</pre>
                            `:""}
                            <div class="code-fix-label">After</div>
                            <pre class="code-fix-pre">${o.codeFix.after}</pre>
                          </div>
                        `:""}
                      </div>
                    </div>
                  `)}
                  ${(s.positives||[]).map(o=>n`
                    <div class="positive-item">
                      <span class="positive-dot"></span>
                      <span>${o}</span>
                    </div>
                  `)}
                </div>
              `:""}
            </div>
          `})}
        </div>
      `:""}

      ${e.accessibilityResults?n`
        <div class="section-header">Accessibility Audit</div>
        <div class="a11y-section">
          <div class="a11y-card">
            <div class="a11y-header">
              <span class="a11y-title">${e.accessibilityResults.passCount} pass · ${e.accessibilityResults.warnCount} warn · ${e.accessibilityResults.failCount} fail</span>
              <span class="a11y-score-badge ${this._getScoreClass(e.accessibilityResults.score)}">${e.accessibilityResults.score}</span>
            </div>
            ${(e.accessibilityResults.checks||[]).map(s=>n`
              <div class="a11y-check">
                <span class="check-dot ${s.status}"></span>
                <span class="a11y-name">${s.name}</span>
                <span class="a11y-message" title="${s.message}">${s.message}</span>
              </div>
            `)}
          </div>
        </div>

        ${e.accessibilityResults.wcagViolations?.length>0?n`
          <div class="section-header">WCAG Violations <span style="font-weight: 400; font-size: 10px; text-transform: none; letter-spacing: 0; color: var(--sx-text-tertiary, #8a8a96);">(axe-core)</span></div>
          <div class="a11y-section">
            ${e.accessibilityResults.wcagViolations.map(s=>n`
              <div class="a11y-card" style="margin-bottom: 6px;">
                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                  <span style="
                    font-size: 9px; font-weight: 600; padding: 1px 6px; border-radius: 4px;
                    background: ${s.impact==="critical"?"rgba(239,68,68,0.15)":s.impact==="serious"?"rgba(234,179,8,0.15)":s.impact==="moderate"?"rgba(59,130,246,0.15)":"rgba(138,138,150,0.15)"};
                    color: ${s.impact==="critical"?"#ef4444":s.impact==="serious"?"#eab308":s.impact==="moderate"?"#3b82f6":"#8a8a96"};
                  ">${s.impact}</span>
                  ${s.tags?.length?n`<span style="font-size: 9px; color: var(--sx-text-tertiary, #8a8a96);">${s.tags.join(", ")}</span>`:""}
                </div>
                <div style="font-size: 12px; font-weight: 500; color: var(--sx-text-primary, #ededf0); margin-bottom: 3px;">${s.help}</div>
                <div style="font-size: 11px; color: var(--sx-text-tertiary, #8a8a96); margin-bottom: 4px;">${s.description}</div>
                ${s.nodes?.length?n`
                  <div style="font-size: 10px; color: var(--sx-text-tertiary, #8a8a96); margin-bottom: 3px;">Affected elements (${s.nodes.length}):</div>
                  ${s.nodes.slice(0,3).map(i=>n`
                    <div style="font-size: 10px; font-family: monospace; background: var(--sx-bg-main, #121214); padding: 4px 6px; border-radius: 4px; margin-bottom: 2px; color: var(--sx-text-secondary, #b4b4bc); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${i.target||i.html}</div>
                  `)}
                `:""}
                ${s.helpUrl?n`<a href="${s.helpUrl}" target="_blank" rel="noopener" style="font-size: 10px; color: var(--sx-accent, #3b82f6); text-decoration: none;">Learn more →</a>`:""}
              </div>
            `)}
          </div>
        `:""}

        ${e.accessibilityResults.wcagPasses?n`
          <div style="font-size: 11px; color: var(--sx-text-tertiary, #8a8a96); padding: 4px 0; margin-bottom: 12px;">
            ✓ ${e.accessibilityResults.wcagPasses} WCAG rules passed
          </div>
        `:""}
      `:""}

      <div class="export-bar">
        <div class="export-actions">
          <button class="export-btn ${this.copied?"copied":""}" @click="${this._downloadMarkdown}">
            ${this.copied?"Downloaded \u2713":"\u2193 Markdown"}
          </button>
          <button class="export-btn pdf" @click="${this._downloadPDF}">
            ↓ PDF
          </button>
        </div>
      </div>
    `}_renderHistory(){return!this.history||this.history.length===0?n`
        <div class="history-empty">
          No past reports yet. Analyze a page to start building history.
        </div>
      `:n`
      <div class="section-header" style="padding: 0 0 2px;">Past reports (${this.history.length})</div>
      <div class="history-list">
        ${this.history.map(e=>n`
          <div class="history-item" @click="${()=>this._loadFromHistory(e.id)}">
            <span class="history-score ${this._getScoreClass(e.score)}">${e.score}</span>
            <div class="history-details">
              <div class="history-title">${e.title||e.url||"Untitled"}</div>
              <div class="history-meta">${this._formatDate(e.timestamp)} · ${e.mode} · ${e.model}</div>
            </div>
            <button class="history-delete" @click="${t=>{t.stopPropagation(),this._deleteFromHistory(e.id)}}" title="Delete">×</button>
          </div>
        `)}
      </div>
    `}_loadFromHistory(e){this.dispatchEvent(new CustomEvent("load-report",{detail:{id:e},bubbles:!0,composed:!0}))}_deleteFromHistory(e){this.dispatchEvent(new CustomEvent("delete-report",{detail:{id:e},bubbles:!0,composed:!0}))}_shortenUrl(e){if(!e)return"";try{let t=new URL(e);return t.hostname+(t.pathname!=="/"?t.pathname.substring(0,30)+(t.pathname.length>30?"...":""):"")}catch{return e.substring(0,40)+(e.length>40?"...":"")}}_formatDate(e){if(!e)return"";try{let t=new Date(e),i=new Date-t;return i<6e4?"Just now":i<36e5?`${Math.floor(i/6e4)}m ago`:i<864e5?`${Math.floor(i/36e5)}h ago`:t.toLocaleDateString()}catch{return""}}_copyFix(e){if(!e.codeFix)return;let t=e.codeFix.after;navigator.clipboard.writeText(t).then(()=>{this.copiedFix=e.element,setTimeout(()=>{this.copiedFix=""},2e3)})}_filterIssues(e){return this.activeFilter==="all"?e:e.filter(t=>{switch(this.activeFilter){case"quick-wins":return t.isQuickWin||t.priority==="high"&&t.fixEffort==="easy";case"critical":return t.severity==="critical";case"easy-fixes":return t.fixEffort==="easy";default:return!0}})}_getFilterCounts(e){let t=(e.evaluations||[]).flatMap(s=>s.issues||[]);return{all:t.length,quickWins:t.filter(s=>s.isQuickWin||s.priority==="high"&&s.fixEffort==="easy").length,critical:t.filter(s=>s.severity==="critical").length,easyFixes:t.filter(s=>s.fixEffort==="easy").length}}_renderFilterBar(e){let t=this._getFilterCounts(e);if(t.all===0)return"";let s=[{id:"all",label:"All",count:t.all},{id:"quick-wins",label:"\u26A1 Quick Wins",count:t.quickWins},{id:"critical",label:"\u{1F534} Critical",count:t.critical},{id:"easy-fixes",label:"Easy Fixes",count:t.easyFixes}];return n`
      <div class="filter-bar">
        ${s.map(i=>n`
          <button class="filter-btn ${this.activeFilter===i.id?"active":""}"
            @click="${()=>this.activeFilter=i.id}">
            ${i.label} <span class="filter-count">${i.count}</span>
          </button>
        `)}
      </div>
    `}};customElements.define("synthux-report",se);var ie={ollama:{id:"ollama",name:"Ollama (Local)",icon:"\u{1F5A5}\uFE0F",authType:"none",defaultEndpoint:"http://localhost:11434",models:[],modelsFetchable:!0,buildRequest(r,e,t={}){let s={model:e,prompt:r,system:t.systemPrompt||"",stream:!1,format:t.format||"json",options:{temperature:t.temperature??.3,num_predict:t.maxTokens||2048}};return t.images?.length&&(s.images=t.images.map(i=>i.replace(/^data:image\/\w+;base64,/,""))),{url:`${t.endpoint||this.defaultEndpoint}/api/generate`,method:"POST",headers:{"Content-Type":"application/json"},body:s}},parseResponse(r){try{return{success:!0,result:JSON.parse(r.response),meta:{model:r.model,totalDuration:r.total_duration,inputTokens:r.prompt_eval_count||0,outputTokens:r.eval_count||0}}}catch{return{success:!0,result:{raw:r.response},meta:{model:r.model,inputTokens:r.prompt_eval_count||0,outputTokens:r.eval_count||0}}}},async fetchModels(r){try{let e=await fetch(`${r||this.defaultEndpoint}/api/tags`);return e.ok?((await e.json()).models||[]).map(s=>({id:s.name,name:s.name,size:s.size})):[]}catch{return[]}},async ping(r){let e=r||this.defaultEndpoint;try{let t=await fetch(`${e}/api/tags`,{signal:AbortSignal.timeout(5e3)});if(t.ok){try{if((await fetch(`${e}/api/generate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:""}),signal:AbortSignal.timeout(3e3)})).status===403)return{status:"cors-blocked"}}catch{return{status:"cors-blocked"}}let s=null;try{let i=await fetch(`${e}/api/version`,{signal:AbortSignal.timeout(3e3)});i.ok&&(s=(await i.json()).version||null)}catch{}return{status:"connected",version:s}}return{status:"error",code:t.status}}catch{try{return await fetch(e,{mode:"no-cors",signal:AbortSignal.timeout(3e3)}),{status:"cors-blocked"}}catch{return{status:"offline"}}}}},openai:{id:"openai",name:"OpenAI",icon:"\u{1F7E2}",authType:"bearer",defaultEndpoint:"https://api.openai.com",models:[{id:"gpt-5.4",name:"GPT-5.4"},{id:"gpt-5.4-mini",name:"GPT-5.4 Mini"},{id:"gpt-5.4-nano",name:"GPT-5.4 Nano"},{id:"gpt-5.1",name:"GPT-5.1"}],modelsFetchable:!0,buildRequest(r,e,t={}){let s=[];return t.images?.length&&t.images.forEach(i=>{s.push({type:"image_url",image_url:{url:i,detail:"low"}})}),s.push({type:"text",text:r}),{url:`${t.endpoint||this.defaultEndpoint}/v1/chat/completions`,method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t.apiKey}`},body:{model:e,messages:[...t.systemPrompt?[{role:"system",content:t.systemPrompt}]:[],{role:"user",content:t.images?.length?s:r}],temperature:t.temperature??.3,max_tokens:t.maxTokens||2048,response_format:t.format==="json"?{type:"json_object"}:void 0}}},parseResponse(r){let e=r.choices?.[0]?.message?.content||"";try{return{success:!0,result:JSON.parse(e),meta:{model:r.model,inputTokens:r.usage?.prompt_tokens||0,outputTokens:r.usage?.completion_tokens||0}}}catch{return{success:!0,result:{raw:e},meta:{model:r.model,inputTokens:r.usage?.prompt_tokens||0,outputTokens:r.usage?.completion_tokens||0}}}},async fetchModels(r,e){try{let t=await fetch(`${r||this.defaultEndpoint}/v1/models`,{headers:{Authorization:`Bearer ${e}`}});return t.ok?((await t.json()).data||[]).filter(i=>i.id.startsWith("gpt-5")||i.id.startsWith("gpt-4")||i.id.startsWith("o")).map(i=>({id:i.id,name:i.id})).sort((i,a)=>i.name.localeCompare(a.name)):this.models}catch{return this.models}},async ping(r,e){try{return(await fetch(`${r||this.defaultEndpoint}/v1/models`,{headers:{Authorization:`Bearer ${e}`},signal:AbortSignal.timeout(8e3)})).ok}catch{return!1}}},gemini:{id:"gemini",name:"Google Gemini",icon:"\u{1F535}",authType:"query_param",defaultEndpoint:"https://generativelanguage.googleapis.com",models:[{id:"gemini-2.5-flash",name:"Gemini 2.5 Flash"},{id:"gemini-2.5-pro",name:"Gemini 2.5 Pro"},{id:"gemini-2.5-flash-lite",name:"Gemini 2.5 Flash-Lite"},{id:"gemini-3-flash-preview",name:"Gemini 3 Flash (Preview)"},{id:"gemini-3.1-pro-preview",name:"Gemini 3.1 Pro (Preview)"},{id:"gemini-3.1-flash-lite-preview",name:"Gemini 3.1 Flash-Lite (Preview)"}],modelsFetchable:!0,buildRequest(r,e,t={}){let s=t.endpoint||this.defaultEndpoint,i=t.apiKey||"",a=[];return t.images?.length&&t.images.forEach(o=>{a.push({inlineData:{mimeType:"image/jpeg",data:o.replace(/^data:image\/\w+;base64,/,"")}})}),a.push({text:r}),{url:`${s}/v1beta/models/${e}:generateContent?key=${i}`,method:"POST",headers:{"Content-Type":"application/json"},body:{contents:[...t.systemPrompt?[{role:"model",parts:[{text:`System: ${t.systemPrompt}`}]}]:[],{role:"user",parts:a}],generationConfig:{temperature:t.temperature??.3,maxOutputTokens:t.maxTokens||4096,responseMimeType:t.format==="json"?"application/json":"text/plain",thinkingConfig:{thinkingBudget:0}}}}},parseResponse(r){let e=r.candidates?.[0]?.content?.parts?.[0]?.text||"",t=r.usageMetadata||{},s=(t.candidatesTokenCount||0)+(t.thoughtsTokenCount||0);try{return{success:!0,result:JSON.parse(e),meta:{model:r.modelVersion||"",inputTokens:t.promptTokenCount||0,outputTokens:s,thinkingTokens:t.thoughtsTokenCount||0}}}catch{return{success:!0,result:{raw:e},meta:{model:r.modelVersion||"",inputTokens:t.promptTokenCount||0,outputTokens:s,thinkingTokens:t.thoughtsTokenCount||0}}}},async fetchModels(r,e){try{let t=await fetch(`${r||this.defaultEndpoint}/v1beta/models?key=${e}`);return t.ok?((await t.json()).models||[]).filter(i=>i.name.includes("gemini")&&i.supportedGenerationMethods?.includes("generateContent")).map(i=>({id:i.name.replace("models/",""),name:i.displayName||i.name.replace("models/","")})):this.models}catch{return this.models}},async ping(r,e){try{return(await fetch(`${r||this.defaultEndpoint}/v1beta/models?key=${e}`,{signal:AbortSignal.timeout(8e3)})).ok}catch{return!1}}},claude:{id:"claude",name:"Anthropic Claude",icon:"\u{1F7E0}",authType:"x-api-key",defaultEndpoint:"https://api.anthropic.com",models:[{id:"claude-opus-4-7",name:"Claude Opus 4.7"},{id:"claude-sonnet-4-6",name:"Claude Sonnet 4.6"},{id:"claude-haiku-4-5",name:"Claude Haiku 4.5"},{id:"claude-opus-4-6",name:"Claude Opus 4.6"}],modelsFetchable:!0,buildRequest(r,e,t={}){let s=[];return t.images?.length&&t.images.forEach(i=>{s.push({type:"image",source:{type:"base64",media_type:"image/jpeg",data:i.replace(/^data:image\/\w+;base64,/,"")}})}),s.push({type:"text",text:r}),{url:`${t.endpoint||this.defaultEndpoint}/v1/messages`,method:"POST",headers:{"Content-Type":"application/json","x-api-key":t.apiKey||"","anthropic-version":"2024-01-01","anthropic-dangerous-direct-browser-access":"true"},body:{model:e,max_tokens:t.maxTokens||2048,...t.systemPrompt?{system:t.systemPrompt}:{},messages:[{role:"user",content:t.images?.length?s:r}]}}},parseResponse(r){let e=r.content?.[0]?.text||"";try{return{success:!0,result:JSON.parse(e),meta:{model:r.model||"",inputTokens:r.usage?.input_tokens||0,outputTokens:r.usage?.output_tokens||0}}}catch{return{success:!0,result:{raw:e},meta:{model:r.model||"",inputTokens:r.usage?.input_tokens||0,outputTokens:r.usage?.output_tokens||0}}}},async fetchModels(r,e){try{let t=await fetch(`${r||this.defaultEndpoint}/v1/models`,{headers:{"x-api-key":e||"","anthropic-version":"2024-01-01"},signal:AbortSignal.timeout(8e3)});return t.ok?((await t.json()).data||[]).filter(i=>i.id.startsWith("claude")).map(i=>({id:i.id,name:i.display_name||i.id})).sort((i,a)=>i.name.localeCompare(a.name)):this.models}catch{return this.models}},async ping(r,e){try{return(await fetch(`${r||this.defaultEndpoint}/v1/messages`,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":e||"","anthropic-version":"2024-01-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:"claude-haiku-4-5",max_tokens:1,messages:[{role:"user",content:"Hi"}]}),signal:AbortSignal.timeout(1e4)})).ok}catch{return!1}}}};function re(r){return ie[r]||ie.ollama}function Ae(){return Object.values(ie).map(r=>({id:r.id,name:r.name,icon:r.icon,authType:r.authType,models:r.models}))}var oe=class extends m{static properties={ollamaStatus:{type:Object},endpoint:{type:String},model:{type:String},models:{type:Array},language:{type:String},connectionState:{type:String},showSetupGuide:{type:Boolean},errorType:{type:String},providerId:{type:String},apiKey:{type:String},enableVision:{type:Boolean},_saved:{type:Boolean,state:!0},_customProfiles:{type:Array,state:!0},_showProfileForm:{type:Boolean,state:!0}};static styles=g`
    :host {
      display: block;
      padding: 16px;
    }

    .section { margin-bottom: 24px; }

    .section-header {
      font-size: 11px;
      font-weight: 600;
      color: var(--sx-text-tertiary, #8a8a96);
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 10px;
    }

    .settings-card {
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 10px;
      padding: 14px;
    }

    /* ─── Fields ─────────────────────────────── */
    .field { margin-bottom: 12px; }
    .field:last-child { margin-bottom: 0; }

    .field-label {
      display: block;
      font-size: 12px;
      font-weight: 500;
      color: var(--sx-text-secondary, #b4b4bc);
      margin-bottom: 5px;
    }

    .field-input {
      width: 100%;
      padding: 8px 10px;
      background: var(--sx-bg-input, #141416);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      color: var(--sx-text-primary, #ededf0);
      font-size: 13px;
      font-family: inherit;
      outline: none;
      transition: border-color 150ms ease;
      box-sizing: border-box;
    }

    .field-input:focus {
      border-color: var(--sx-accent, #3b82f6);
    }

    .field-select {
      width: 100%;
      padding: 8px 10px;
      background: var(--sx-bg-input, #141416);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      color: var(--sx-text-primary, #ededf0);
      font-size: 13px;
      font-family: inherit;
      outline: none;
      cursor: pointer;
      box-sizing: border-box;
      -webkit-appearance: none;
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2363636e' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 10px center;
      padding-right: 28px;
    }

    .field-select:focus { border-color: var(--sx-accent, #3b82f6); }

    /* ─── Buttons ─────────────────────────────── */
    .test-btn {
      width: 100%;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-tertiary, #202024);
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
      margin-top: 10px;
    }

    .test-btn:hover { border-color: var(--sx-border-hover, rgba(255,255,255,0.10)); }
    .test-btn.testing { color: var(--sx-accent, #3b82f6); }
    .test-btn.connected {
      color: var(--sx-success, #22c55e);
      border-color: rgba(34, 197, 94, 0.2);
    }
    .test-btn.failed {
      color: var(--sx-error, #ef4444);
      border-color: rgba(239, 68, 68, 0.2);
    }

    .save-btn {
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 8px;
      background: var(--sx-accent, #3b82f6);
      color: white;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
      margin-top: 14px;
    }

    .save-btn:hover { background: var(--sx-accent-hover, #60a5fa); }
    .save-btn.saved { background: var(--sx-success, #22c55e); }

    /* ─── Language ────────────────────────────── */
    .lang-options { display: flex; gap: 6px; }

    .lang-btn {
      flex: 1;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-card, #1c1c1f);
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      text-align: center;
      font-family: inherit;
    }

    .lang-btn:hover { border-color: var(--sx-border-hover, rgba(255,255,255,0.10)); }
    .lang-btn.active {
      border-color: var(--sx-accent, #3b82f6);
      color: var(--sx-text-primary, #ededf0);
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
    }

    /* ─── Setup Guide ────────────────────────── */
    .setup-guide {
      margin-bottom: 20px;
    }

    .setup-toggle {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
      color: var(--sx-text-secondary, #b4b4bc);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .setup-toggle:hover {
      border-color: var(--sx-border-hover, rgba(255,255,255,0.10));
    }

    .setup-chevron {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      transition: transform 150ms ease;
    }

    .setup-chevron.open { transform: rotate(90deg); }

    .setup-content {
      margin-top: 8px;
      padding: 14px;
      background: var(--sx-bg-card, #1c1c1f);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 8px;
    }

    .setup-step {
      margin-bottom: 14px;
    }

    .setup-step:last-child { margin-bottom: 0; }

    .step-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: var(--sx-accent-dim, rgba(59,130,246,0.12));
      color: var(--sx-accent, #3b82f6);
      font-size: 10px;
      font-weight: 700;
      margin-right: 6px;
    }

    .step-title {
      font-size: 12px;
      font-weight: 500;
      color: var(--sx-text-primary, #ededf0);
      margin-bottom: 5px;
    }

    .step-desc {
      font-size: 11px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
      margin-bottom: 6px;
    }

    .code-block {
      position: relative;
      background: var(--sx-bg-input, #141416);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 6px;
      padding: 8px 10px;
      padding-top: 28px;
    }

    .code-block code {
      display: block;
      font-family: 'SF Mono', Monaco, 'Fira Code', monospace;
      font-size: 11px;
      color: var(--sx-text-primary, #ededf0);
      line-height: 1.6;
      white-space: pre-wrap;
      word-break: break-all;
      text-align: left;
    }

    .copy-btn {
      position: absolute;
      top: 4px;
      right: 4px;
      padding: 3px 8px;
      border: none;
      border-radius: 4px;
      background: var(--sx-bg-tertiary, #202024);
      color: var(--sx-text-tertiary, #8a8a96);
      font-size: 10px;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }

    .copy-btn:hover {
      color: var(--sx-text-primary, #ededf0);
    }

    .copy-btn.copied {
      color: var(--sx-success, #22c55e);
    }

    .error-hint {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      padding: 10px 12px;
      background: var(--sx-warning-dim, rgba(234,179,8,0.10));
      border: 1px solid rgba(234, 179, 8, 0.15);
      border-radius: 8px;
      font-size: 11px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
      margin-top: 10px;
    }

    .error-hint-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--sx-warning, #eab308);
      flex-shrink: 0;
      margin-top: 5px;
    }

    .error-hint strong {
      color: var(--sx-warning, #eab308);
    }

    /* ─── API Key ─────────────────────────── */
    .field-input.api-key {
      font-family: 'SF Mono', Monaco, monospace;
      font-size: 11px;
      letter-spacing: 0.5px;
    }

    .api-key-hint {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 4px;
      line-height: 1.4;
    }

    .api-key-hint a {
      color: var(--sx-accent, #3b82f6);
      text-decoration: none;
    }

    .provider-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 3px;
      background: var(--sx-accent-dim, rgba(59,130,246,0.08));
      color: var(--sx-accent, #3b82f6);
      margin-left: 6px;
    }

    /* ─── About ──────────────────────────────── */
    .about-card {
      text-align: center;
      padding: 20px 14px;
    }

    .about-name {
      font-size: 15px;
      font-weight: 700;
      color: var(--sx-text-primary, #ededf0);
      margin-bottom: 2px;
    }

    .about-version {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-bottom: 10px;
    }

    .about-desc {
      font-size: 12px;
      color: var(--sx-text-secondary, #b4b4bc);
      line-height: 1.5;
      margin-bottom: 12px;
    }

    .about-links { display: flex; gap: 16px; justify-content: center; }

    .about-link {
      font-size: 12px;
      color: var(--sx-accent, #3b82f6);
      text-decoration: none;
      font-weight: 500;
    }

    .about-link:hover { text-decoration: underline; }

    .about-license {
      font-size: 10px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin-top: 10px;
    }

    /* ─── Toggle Switch ──────────────────────── */
    .toggle-switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 22px;
      flex-shrink: 0;
    }
    .toggle-switch input { opacity: 0; width: 0; height: 0; }
    .toggle-slider {
      position: absolute;
      cursor: pointer;
      inset: 0;
      background: var(--sx-bg-tertiary, #202024);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 22px;
      transition: all 200ms ease;
    }
    .toggle-slider::before {
      content: '';
      position: absolute;
      width: 16px;
      height: 16px;
      left: 2px;
      bottom: 2px;
      background: var(--sx-text-tertiary, #8a8a96);
      border-radius: 50%;
      transition: all 200ms ease;
    }
    .toggle-switch input:checked + .toggle-slider {
      background: var(--sx-accent-dim, rgba(59,130,246,0.15));
      border-color: var(--sx-accent, #3b82f6);
    }
    .toggle-switch input:checked + .toggle-slider::before {
      transform: translateX(18px);
      background: var(--sx-accent, #3b82f6);
    }
  `;constructor(){super(),this.ollamaStatus={connected:!1,models:[]},this.endpoint="http://localhost:11434",this.model="gemma4:31b",this.models=[],this.language="en",this.connectionState="idle",this.showSetupGuide=!1,this.errorType="",this.providerId="ollama",this.apiKey="",this.enableVision=!0,this._saved=!1,this._copiedCmd="",this._customProfiles=[],this._showProfileForm=!1,this._loadSettings(),this._loadCustomProfiles()}updated(e){if(e.has("ollamaStatus")&&this.ollamaStatus?.connected&&this.providerId==="ollama"){let t=(this.ollamaStatus.models||[]).map(s=>s.name||s.id||s);t.length>0&&JSON.stringify(t)!==JSON.stringify(this.models)&&(this.models=t,this.model&&!this.models.includes(this.model)&&this.models.length>0)}}get _isCloudProvider(){return this.providerId!=="ollama"}async _loadSettings(){try{let e=await chrome.storage.local.get({ollamaEndpoint:"http://localhost:11434",ollamaModel:"gemma4:31b",language:"en",providerId:"ollama",apiKey:"",apiKey_openai:"",apiKey_gemini:"",apiKey_claude:"",enableVision:!0});this.endpoint=e.ollamaEndpoint,this.model=e.ollamaModel,this.language=e.language,this.providerId=e.providerId,this.apiKey=e[`apiKey_${this.providerId}`]||e.apiKey||"",this.enableVision=e.enableVision!==!1,this._updateModelsForProvider()}catch{}}async _testConnection(){this.connectionState="testing",this.errorType="";let e=re(this.providerId);try{let t=await e.ping(this.endpoint,this.apiKey),s=typeof t=="object"?t.status==="connected":!!t,i=typeof t=="object"&&t.status==="cors-blocked";if(s){let a=await e.fetchModels(this.endpoint,this.apiKey);this.models=a.map(o=>o.id||o.name),this.connectionState="connected",this.errorType="",this.models.length>0&&!this.models.includes(this.model)&&(this.model=this.models[0]),this.dispatchEvent(new CustomEvent("status-changed",{detail:{connected:!0,models:a,provider:this.providerId}}))}else i?(this.connectionState="failed",this.errorType="cors",this.showSetupGuide=!0,this.dispatchEvent(new CustomEvent("status-changed",{detail:{connected:!1,corsBlocked:!0,models:[]}}))):(this.connectionState="failed",this.errorType=this._isCloudProvider?"auth":"offline",this._isCloudProvider||(this.showSetupGuide=!0),this.dispatchEvent(new CustomEvent("status-changed",{detail:{connected:!1,models:[]}})))}catch(t){this.connectionState="failed",this.errorType=t.name==="TimeoutError"?"timeout":this._isCloudProvider?"auth":"offline",this._isCloudProvider||(this.showSetupGuide=!0),this.dispatchEvent(new CustomEvent("status-changed",{detail:{connected:!1,models:[]}}))}setTimeout(()=>{this.connectionState==="connected"&&(this.connectionState="idle")},3e3)}_updateModelsForProvider(){let e=re(this.providerId);this.providerId==="ollama"?(this.endpoint="http://localhost:11434",this.ollamaStatus?.connected&&this.ollamaStatus?.provider==="ollama"?this.models=(this.ollamaStatus.models||[]).map(t=>t.name||t.id||t):this.models=[],this.models.length>0&&!this.models.includes(this.model)||this.model||(this.model=this.models[0]||"gemma4:31b")):(this.endpoint=e.defaultEndpoint,this.models=(e.models||[]).map(t=>t.id),this.models.length>0&&!this.models.includes(this.model)&&(this.model=this.models[0])),this.connectionState="idle"}async _onProviderChange(e){this.providerId=e.target.value;try{let t=await chrome.storage.local.get(`apiKey_${this.providerId}`);this.apiKey=t[`apiKey_${this.providerId}`]||""}catch{this.apiKey=""}this._updateModelsForProvider(),this._autoSave(),this.apiKey&&this.providerId!=="ollama"&&this._testConnection()}_onApiKeyBlur(){this.apiKey&&this.apiKey.length>5&&(this._autoSave(),this._testConnection())}_onModelChange(e){this.model=e.target.value,this._autoSave()}_onLanguageChange(e){this.language=e,this._autoSave()}_onEndpointBlur(){this._autoSave()}async _autoSave(){try{let e={ollamaEndpoint:this.endpoint,ollamaModel:this.model,language:this.language,providerId:this.providerId,apiKey:this.apiKey,enableVision:this.enableVision};this.providerId!=="ollama"&&this.apiKey&&(e[`apiKey_${this.providerId}`]=this.apiKey),await chrome.runtime.sendMessage({type:"SAVE_SETTINGS",payload:e}),this._saved=!0,clearTimeout(this._savedTimer),this._savedTimer=setTimeout(()=>{this._saved=!1},2e3)}catch(e){console.error("[synthux] Auto-save failed:",e)}}async _saveSettings(){await this._autoSave()}async _loadCustomProfiles(){try{this._customProfiles=await A()}catch{this._customProfiles=[]}}async _saveProfile(){let e=this.shadowRoot.getElementById("cp-name")?.value?.trim();if(!e)return;let t=this.shadowRoot.getElementById("cp-age")?.value||"25-35",s=this.shadowRoot.getElementById("cp-tech")?.value||"medium",i=this.shadowRoot.getElementById("cp-goal")?.value?.trim()||"",a=this.shadowRoot.querySelectorAll(".cp-disability:checked"),o=Array.from(a).map(c=>c.value);try{await j({name:e,description:`${t}, ${s} tech${i?` \u2014 ${i}`:""}`,ageRange:t,techLevel:s,disabilities:o,goal:i,priorityHeuristics:[]}),this._showProfileForm=!1,await this._loadCustomProfiles(),this.dispatchEvent(new CustomEvent("profiles-changed",{bubbles:!0,composed:!0}))}catch(c){console.error("[synthux] Failed to save profile:",c)}}async _deleteProfile(e){try{await I(e),await this._loadCustomProfiles(),this.dispatchEvent(new CustomEvent("profiles-changed",{bubbles:!0,composed:!0}))}catch(t){console.error("[synthux] Failed to delete profile:",t)}}async _copyCommand(e,t){try{await navigator.clipboard.writeText(e)}catch{let s=document.createElement("textarea");s.value=e,document.body.appendChild(s),s.select(),document.execCommand("copy"),document.body.removeChild(s)}this._copiedCmd=t,this.requestUpdate(),setTimeout(()=>{this._copiedCmd="",this.requestUpdate()},2e3)}_getTestLabel(){switch(this.connectionState){case"testing":return"Testing...";case"connected":return"Connected";case"failed":return this.errorType==="cors"?"Blocked (CORS)":this.errorType==="timeout"?"Timed out":this.errorType==="offline"?"Not reachable":this.errorType==="auth"?"Invalid API key":"Connection failed";default:return"Test Connection"}}_getApiKeyHint(){switch(this.providerId){case"openai":return n`Get your key at <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a>`;case"gemini":return n`Get your key at <a href="https://aistudio.google.com/apikey" target="_blank">AI Studio</a>`;case"claude":return n`Get your key at <a href="https://console.anthropic.com/" target="_blank">console.anthropic.com</a>`;default:return""}}_detectOS(){let e=navigator.userAgent.toLowerCase();return e.includes("mac")?"mac":e.includes("win")?"win":"linux"}_getCorsCommand(){let e=this._detectOS();return e==="mac"?'launchctl setenv OLLAMA_ORIGINS "*"':e==="win"?'[Environment]::SetEnvironmentVariable("OLLAMA_ORIGINS", "*", "User")':"sudo systemctl edit ollama"}_getCorsNote(){let e=this._detectOS();return e==="win"?"Run in PowerShell as Administrator":e==="linux"?'Add under [Service]: Environment="OLLAMA_ORIGINS=*"':null}_getOtherPlatformCommands(){let e=this._detectOS(),s=Object.entries({mac:{name:"macOS",cmd:'launchctl setenv OLLAMA_ORIGINS "*"'},linux:{name:"Linux",cmd:'sudo systemctl edit ollama \u2192 Environment="OLLAMA_ORIGINS=*"'},win:{name:"Windows",cmd:'[Environment]::SetEnvironmentVariable("OLLAMA_ORIGINS", "*", "User")'}}).filter(([i])=>i!==e);return n`${s.map(([,i])=>n`<div style="margin-bottom: 4px;"><strong>${i.name}:</strong> <code style="font-size: 10px;">${i.cmd}</code></div>`)}`}render(){let e=Ae();return n`
      <div class="section">
        <div class="section-header">AI Provider</div>
        <div class="settings-card">
          <div class="field">
            <label class="field-label">Provider</label>
            <select class="field-select" .value="${this.providerId}" @change="${this._onProviderChange}">
              ${e.map(t=>n`<option value="${t.id}" ?selected="${t.id===this.providerId}">${t.icon} ${t.name}</option>`)}
            </select>
          </div>

          ${this._isCloudProvider?n`
            <div class="field">
              <label class="field-label">API Key</label>
              <input class="field-input api-key" type="password" .value="${this.apiKey}" @input="${t=>this.apiKey=t.target.value}" @blur="${this._onApiKeyBlur}" placeholder="Enter API key..." />
              <div class="api-key-hint">${this._getApiKeyHint()}</div>
            </div>
          `:n`
            <div class="field">
              <label class="field-label">Endpoint</label>
              <input class="field-input" type="url" .value="${this.endpoint}" @input="${t=>this.endpoint=t.target.value}" @blur="${this._onEndpointBlur}" placeholder="http://localhost:11434" />
            </div>
          `}

          <div class="field">
            <label class="field-label">Model</label>
            ${this.models.length>0?n`
              <select class="field-select" .value="${this.model}" @change="${this._onModelChange}">
                ${this.models.map(t=>n`<option value="${t}" ?selected="${t===this.model}">${t}</option>`)}
              </select>
            `:n`
              <input class="field-input" type="text" .value="${this.model}" @input="${t=>this.model=t.target.value}" @blur="${()=>this._autoSave()}" placeholder="gemma4:31b" />
            `}
          </div>
          <button class="test-btn ${this.connectionState}" @click="${this._testConnection}" ?disabled="${this.connectionState==="testing"}">${this._getTestLabel()}</button>
        </div>

        ${this.errorType==="cors"?n`
          <div class="error-hint">
            <span class="error-hint-dot"></span>
            <div>
              <strong>CORS blocked.</strong> Ollama needs permission to accept requests from Chrome extensions. See the setup guide below.
            </div>
          </div>
        `:""}

        ${this.errorType==="auth"?n`
          <div class="error-hint">
            <span class="error-hint-dot"></span>
            <div>
              <strong>Invalid API key.</strong> Check your API key and try again.
            </div>
          </div>
        `:""}

        ${(this.errorType==="offline"||this.errorType==="timeout")&&!this._isCloudProvider?n`
          <div class="error-hint">
            <span class="error-hint-dot"></span>
            <div>
              <strong>Ollama not running.</strong> Make sure Ollama is installed and running on your machine.
            </div>
          </div>
        `:""}
      </div>

      ${this._isCloudProvider?"":n`
      <div class="setup-guide">
        <button class="setup-toggle" @click="${()=>this.showSetupGuide=!this.showSetupGuide}">
          Ollama Setup Guide
          <span class="setup-chevron ${this.showSetupGuide?"open":""}">▶</span>
        </button>

        ${this.showSetupGuide?n`
          <div class="setup-content">
            <div class="setup-step">
              <div class="step-title"><span class="step-number">1</span> Install Ollama</div>
              <div class="step-desc">Download from ollama.com and install.</div>
              <div class="code-block">
                <button class="copy-btn ${this._copiedCmd==="url"?"copied":""}" @click="${()=>this._copyCommand("https://ollama.com/download","url")}">${this._copiedCmd==="url"?"Copied":"Copy"}</button>
                <code>https://ollama.com/download</code>
              </div>
            </div>

            <div class="setup-step">
              <div class="step-title"><span class="step-number">2</span> Download a model</div>
              <div class="step-desc">Pull a language model. Any model works:</div>
              <div class="code-block">
                <button class="copy-btn ${this._copiedCmd==="pull"?"copied":""}" @click="${()=>this._copyCommand("ollama pull gemma4","pull")}">${this._copiedCmd==="pull"?"Copied":"Copy"}</button>
                <code>ollama pull gemma4</code>
              </div>
              <div class="step-desc" style="margin-top: 6px; font-size: 10px; color: var(--sx-text-tertiary);">Alternatives: <code style="font-size: 10px;">ollama pull gemma4:e4b</code> (smaller) or <code style="font-size: 10px;">ollama pull qwen3.5</code></div>
            </div>

            <div class="setup-step">
              <div class="step-title"><span class="step-number">3</span> Allow extension access</div>
              <div class="step-desc">Ollama blocks browser extensions by default. Run this in Terminal:</div>
              <div class="code-block">
                <button class="copy-btn ${this._copiedCmd==="cors"?"copied":""}" @click="${()=>this._copyCommand(this._getCorsCommand(),"cors")}">${this._copiedCmd==="cors"?"Copied":"Copy"}</button>
                <code>${this._getCorsCommand()}</code>
              </div>
              ${this._getCorsNote()?n`<div class="step-desc" style="margin-top: 4px; font-size: 10px; color: var(--sx-text-tertiary);">${this._getCorsNote()}</div>`:""}
              <details style="margin-top: 6px; font-size: 10px; color: var(--sx-text-tertiary);">
                <summary style="cursor: pointer;">Other platforms</summary>
                <div style="padding: 6px 0;">${this._getOtherPlatformCommands()}</div>
              </details>
            </div>

            <div class="setup-step">
              <div class="step-title"><span class="step-number">4</span> Quit and restart Ollama</div>
              <div class="step-desc">Close Ollama completely, then reopen it. The CORS setting won't take effect until restarted.</div>
              <div class="step-desc" style="font-size: 10px; color: var(--sx-text-tertiary);">Ollama updates may reset this setting. If you get a CORS error after updating, repeat step 3 and restart.</div>
            </div>
          </div>
        `:""}
      </div>
      `}

      <div class="section">
        <div class="section-header">Analysis</div>
        <div class="settings-card" style="display: flex; align-items: center; justify-content: space-between;">
          <div>
            <div style="font-size: 13px; font-weight: 500; color: var(--sx-text-primary, #ededf0);">Screenshot Analysis</div>
            <div style="font-size: 11px; color: var(--sx-text-tertiary, #8a8a96); margin-top: 2px;">Send page screenshot to AI for visual analysis</div>
          </div>
          <label class="toggle-switch">
            <input type="checkbox" .checked="${this.enableVision}" @change="${t=>{this.enableVision=t.target.checked,this._autoSave()}}" />
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>

      <div class="save-indicator ${this._saved?"visible":""}" style="text-align: center; padding: 8px; font-size: 11px; color: var(--sx-success, #22c55e); opacity: ${this._saved?"1":"0"}; transition: opacity 300ms ease;">✓ Auto-saved</div>


      <div class="section" style="margin-top: 32px;">
        <div class="section-header">About</div>
        <div class="settings-card about-card">
          <div class="about-name">synthux</div>
          <div class="about-version">v${chrome.runtime?.getManifest?.()?.version||"1.9.0"}</div>
          <div class="about-desc">AI-powered UX audit. Open source. Privacy first.</div>
          <div class="about-links">
            <a class="about-link" href="https://synthux.app" target="_blank">Website</a>
            <a class="about-link" href="https://github.com/synthuxapp/synthux" target="_blank">GitHub</a>
          </div>
          <div class="about-license">MIT License</div>
        </div>
      </div>
    `}};customElements.define("synthux-settings",oe);var ae=class extends m{static properties={activeTab:{type:String},ollamaStatus:{type:Object},report:{type:Object},reportHistory:{type:Array},analysisProgress:{type:Object},isAnalyzing:{type:Boolean}};static styles=g`
    :host {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: var(--sx-bg-primary, #111113);
      color: var(--sx-text-primary, #ededf0);
      font-family: var(--sx-font-family, 'Inter', sans-serif);
    }

    /* ─── Header ─────────────────────────────── */
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      border-bottom: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-secondary, #18181b);
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .logo-img {
      height: 20px;
      width: auto;
    }

    .status-badge {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      padding: 4px 10px;
      border-radius: 20px;
      font-weight: 500;
    }

    .status-badge.connected {
      color: var(--sx-success, #22c55e);
      background: var(--sx-success-dim, rgba(34,197,94,0.10));
    }

    .status-badge.cors-error {
      color: var(--sx-warning, #eab308);
      background: var(--sx-warning-dim, rgba(234,179,8,0.10));
    }

    .status-badge.version-warn {
      color: #f97316;
      background: rgba(249,115,22,0.10);
    }

    .status-badge.disconnected {
      color: var(--sx-text-tertiary, #8a8a96);
      background: var(--sx-bg-tertiary, #202024);
    }

    .status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
    }

    .status-dot.connected {
      background: var(--sx-success, #22c55e);
    }

    .status-dot.cors-error {
      background: var(--sx-warning, #eab308);
    }

    .status-dot.version-warn {
      background: #f97316;
    }

    .status-dot.disconnected {
      background: var(--sx-text-tertiary, #8a8a96);
    }

    /* ─── Tabs ────────────────────────────────── */
    .tab-bar {
      display: flex;
      border-bottom: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      background: var(--sx-bg-secondary, #18181b);
    }

    .tab {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10px 0;
      font-size: 12px;
      font-weight: 600;
      color: var(--sx-text-tertiary, #8a8a96);
      background: none;
      border: none;
      border-bottom: 2px solid transparent;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
      letter-spacing: 0.2px;
    }

    .tab:hover {
      color: var(--sx-text-secondary, #b4b4bc);
    }

    .tab.active {
      color: var(--sx-text-primary, #ededf0);
      border-bottom-color: var(--sx-accent, #3b82f6);
    }

    /* ─── Content ─────────────────────────────── */
    .content {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
    }

    .tab-panel {
      display: none;
      animation: fadeIn 200ms ease;
    }

    .tab-panel.active {
      display: block;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    /* ─── Rating Toast ───────────────────────── */
    #rating-toast {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 100;
      padding: 12px;
      animation: slideUp 0.3s ease;
    }

    #rating-toast.rating-toast-exit {
      animation: slideDown 0.3s ease forwards;
    }

    .rating-toast {
      background: var(--sx-bg-secondary, #18181b);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
      border-radius: 10px;
      padding: 14px 16px;
      box-shadow: 0 -4px 24px rgba(0,0,0,0.3);
    }

    .rating-toast__header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 6px;
    }

    .rating-toast__icon {
      color: #eab308;
      font-size: 14px;
    }

    .rating-toast__title {
      font-size: 13px;
      font-weight: 600;
      color: var(--sx-text-primary, #ededf0);
    }

    .rating-toast__desc {
      font-size: 11px;
      color: var(--sx-text-tertiary, #8a8a96);
      margin: 0 0 12px;
      line-height: 1.4;
    }

    .rating-toast__actions {
      display: flex;
      gap: 8px;
    }

    .rating-toast__btn {
      flex: 1;
      padding: 7px 0;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      font-family: inherit;
      cursor: pointer;
      border: none;
      transition: all 150ms ease;
    }

    .rating-toast__btn--primary {
      background: var(--sx-accent, #3b82f6);
      color: #fff;
    }

    .rating-toast__btn--primary:hover {
      background: #2563eb;
    }

    .rating-toast__btn--secondary {
      background: var(--sx-bg-tertiary, #202024);
      color: var(--sx-text-tertiary, #8a8a96);
      border: 1px solid var(--sx-border, rgba(255,255,255,0.06));
    }

    .rating-toast__btn--secondary:hover {
      color: var(--sx-text-secondary, #b4b4bc);
    }

    @keyframes slideUp {
      from { transform: translateY(100%); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    @keyframes slideDown {
      from { transform: translateY(0); opacity: 1; }
      to { transform: translateY(100%); opacity: 0; }
    }
  `;constructor(){super(),this.activeTab="scan",this.ollamaStatus={connected:!1,models:[]},this.report=null,this.reportHistory=[],this.analysisProgress=null,this.isAnalyzing=!1;try{this._port=chrome.runtime.connect({name:"sidepanel"})}catch{}this._setupMessageListeners(),this._checkOllamaStatus(),this._startHealthCheck(),this._loadLastReport(),this._loadHistory()}_setupMessageListeners(){chrome.runtime.onMessage.addListener(e=>{switch(e.type){case"ANALYSIS_PROGRESS":this.analysisProgress=e.payload,this.isAnalyzing=!0;break;case"ANALYSIS_COMPLETE":this.report=e.payload,this.isAnalyzing=!1,this.analysisProgress=null,this.activeTab="report",this._loadHistory(),this._maybeShowRatingPrompt();break;case"ANALYSIS_ERROR":this.isAnalyzing=!1,this.analysisProgress=null,msg.payload?.errorType==="cors"&&(this.ollamaStatus={...this.ollamaStatus,connected:!1,corsBlocked:!0},this.activeTab="scan");break;case"ANALYSIS_CANCELLED":this.isAnalyzing=!1,this.analysisProgress=null;break}})}async _checkOllamaStatus(){try{let e=await chrome.runtime.sendMessage({type:"GET_OLLAMA_STATUS"});this.ollamaStatus=e||{connected:!1,models:[]}}catch{this.ollamaStatus={connected:!1,models:[]}}}_startHealthCheck(){this._healthInterval=setInterval(()=>this._checkOllamaStatus(),15e3)}disconnectedCallback(){super.disconnectedCallback(),this._healthInterval&&clearInterval(this._healthInterval)}async _loadLastReport(){try{let e=await chrome.storage.local.get("lastReport");e.lastReport&&(this.report=e.lastReport)}catch{}}async _loadHistory(){try{let e=await chrome.runtime.sendMessage({type:"GET_REPORT_HISTORY"});this.reportHistory=e||[]}catch{this.reportHistory=[]}}async _loadHistoryReport(e){let{id:t}=e.detail;try{let s=await chrome.runtime.sendMessage({type:"LOAD_REPORT",payload:{id:t}});s?.report&&(this.report=s.report,this.activeTab="report")}catch(s){console.error("[synthux] Failed to load report:",s)}}async _deleteHistoryReport(e){let{id:t}=e.detail;try{let s=await chrome.runtime.sendMessage({type:"DELETE_REPORT",payload:{id:t}});s?.success&&(this.reportHistory=s.history)}catch(s){console.error("[synthux] Failed to delete report:",s)}}_setTab(e){this.activeTab=e,e==="scan"&&this._checkOllamaStatus()}_handleAnalysisStart(){this.isAnalyzing=!0}_handleAnalysisEnd(){this.isAnalyzing=!1,this.analysisProgress=null}_getStatusInfo(){let e=this.ollamaStatus;return e?.connected&&e?.versionChanged?{cls:"version-warn",label:`Updated (${e.newVersion})`}:e?.connected?{cls:"connected",label:"Connected"}:e?.corsBlocked?{cls:"cors-error",label:"CORS Error"}:{cls:"disconnected",label:"Offline"}}render(){let e=this._getStatusInfo();return n`
      <!-- Header -->
      <div class="header">
        <div class="logo">
          <img class="logo-img" src="../assets/logo.svg" alt="synthux" />
        </div>
        <div class="status-badge ${e.cls}">
          <span class="status-dot ${e.cls}"></span>
          ${e.label}
        </div>
      </div>

      <!-- Tab Bar -->
      <div class="tab-bar" role="tablist">
        <button 
          class="tab ${this.activeTab==="scan"?"active":""}"
          role="tab"
          aria-selected="${this.activeTab==="scan"}"
          @click="${()=>this._setTab("scan")}"
        >Scan</button>
        <button 
          class="tab ${this.activeTab==="report"?"active":""}"
          role="tab"
          aria-selected="${this.activeTab==="report"}"
          @click="${()=>this._setTab("report")}"
        >Report</button>
        <button 
          class="tab ${this.activeTab==="history"?"active":""}"
          role="tab"
          aria-selected="${this.activeTab==="history"}"
          @click="${()=>{this._setTab("history"),this._loadHistory()}}"
        >History</button>
        <button 
          class="tab ${this.activeTab==="settings"?"active":""}"
          role="tab"
          aria-selected="${this.activeTab==="settings"}"
          @click="${()=>this._setTab("settings")}"
        >Settings</button>
      </div>

      <!-- Content -->
      <div class="content">
        <div class="tab-panel ${this.activeTab==="scan"?"active":""}" role="tabpanel">
          <synthux-scanner
            .ollamaStatus="${this.ollamaStatus}"
            .isAnalyzing="${this.isAnalyzing}"
            .progress="${this.analysisProgress}"
            @analysis-start="${this._handleAnalysisStart}"
            @analysis-end="${this._handleAnalysisEnd}"
          ></synthux-scanner>
        </div>

        <div class="tab-panel ${this.activeTab==="report"?"active":""}" role="tabpanel">
          <synthux-report
            .report="${this.report}"
          ></synthux-report>
        </div>

        <div class="tab-panel ${this.activeTab==="history"?"active":""}" role="tabpanel">
          <synthux-report
            .report="${null}"
            .history="${this.reportHistory}"
            showHistory
            @load-report="${this._loadHistoryReport}"
            @delete-report="${this._deleteHistoryReport}"
          ></synthux-report>
        </div>

        <div class="tab-panel ${this.activeTab==="settings"?"active":""}" role="tabpanel">
          <synthux-settings
            .ollamaStatus="${this.ollamaStatus}"
            @status-changed="${t=>this.ollamaStatus=t.detail}"
          ></synthux-settings>
        </div>
      </div>
    `}async _maybeShowRatingPrompt(){try{let e=await chrome.storage.local.get(["synthux_rating_dismissed","synthux_analysis_count"]);if(e.synthux_rating_dismissed)return;let t=(e.synthux_analysis_count||0)+1;if(await chrome.storage.local.set({synthux_analysis_count:t}),t<1)return;setTimeout(()=>this._showRatingToast(),2e3)}catch{}}_showRatingToast(){if(this.shadowRoot.getElementById("rating-toast"))return;let e=document.createElement("div");e.id="rating-toast",e.innerHTML=`
      <div class="rating-toast">
        <div class="rating-toast__header">
          <span class="rating-toast__icon">\u2605</span>
          <span class="rating-toast__title">Enjoying synthux?</span>
        </div>
        <p class="rating-toast__desc">A quick rating on the Chrome Web Store helps others discover synthux.</p>
        <div class="rating-toast__actions">
          <button class="rating-toast__btn rating-toast__btn--primary" id="rating-rate">Rate synthux</button>
          <button class="rating-toast__btn rating-toast__btn--secondary" id="rating-dismiss">Maybe later</button>
        </div>
      </div>
    `,this.shadowRoot.appendChild(e),e.querySelector("#rating-rate").addEventListener("click",()=>{window.open("https://chromewebstore.google.com/detail/synthux/cgldigellmojaejmnhjhpbfccncbmnhm/reviews","_blank"),chrome.storage.local.set({synthux_rating_dismissed:!0}),e.remove()}),e.querySelector("#rating-dismiss").addEventListener("click",()=>{chrome.storage.local.set({synthux_rating_dismissed:!0}),e.classList.add("rating-toast-exit"),setTimeout(()=>e.remove(),300)})}};customElements.define("synthux-app",ae);export{ae as SynthuxApp};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
